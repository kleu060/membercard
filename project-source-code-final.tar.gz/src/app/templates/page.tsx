'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import AuthForm from '@/components/auth/AuthForm';
import Dashboard from '@/components/dashboard/Dashboard';
import LanguageSelector from '@/components/LanguageSelector';
import NamecardTemplates from '@/components/namecard/NamecardTemplates';
import { useLanguage } from '@/contexts/LanguageContext';

export default function TemplatesPage() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showAuth, setShowAuth] = useState(false);
  const { language, setLanguage, t } = useLanguage();

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const response = await fetch('/api/auth/me');
      if (response.ok) {
        const data = await response.json();
        setUser(data.user);
      }
    } catch (error) {
      // User not authenticated
    } finally {
      setLoading(false);
    }
  };

  const handleAuthSuccess = () => {
    checkAuth();
    setShowAuth(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">{t('loading')}</p>
        </div>
      </div>
    );
  }

  if (showAuth) {
    return <AuthForm onSuccess={handleAuthSuccess} />;
  }

  if (user) {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-white shadow-sm border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <div className="flex items-center space-x-4">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                  </svg>
                </div>
                <h1 className="text-xl font-bold text-gray-900">APEXCARD</h1>
              </div>
              <nav className="flex items-center space-x-6">
                <a href="/" className="text-gray-600 hover:text-blue-600 transition-colors">
                  {language === 'zh-TW' ? '首頁' : language === 'zh-CN' ? '首页' : 'Home'}
                </a>
                <a href="/templates" className="text-blue-600 font-medium">
                  {language === 'zh-TW' ? '名片模板' : language === 'zh-CN' ? '名片模板' : 'Templates'}
                </a>
                <a href="/scan" className="text-gray-600 hover:text-blue-600 transition-colors">
                  {language === 'zh-TW' ? '名片掃描' : language === 'zh-CN' ? '名片扫描' : 'Card Scanner'}
                </a>
                <a href="/job-market" className="text-gray-600 hover:text-blue-600 transition-colors">
                  {language === 'zh-TW' ? '就業市場' : language === 'zh-CN' ? '就业市场' : 'Job Market'}
                </a>
                <a href="/features" className="text-gray-600 hover:text-blue-600 transition-colors">
                  {language === 'zh-TW' ? '高級功能' : language === 'zh-CN' ? '高级功能' : 'Features'}
                </a>
                <a href="/marketplace" className="text-gray-600 hover:text-blue-600 transition-colors">
                  {language === 'zh-TW' ? '名片市場' : language === 'zh-CN' ? '名片市场' : 'Marketplace'}
                </a>
              </nav>
              <div className="flex items-center space-x-4">
                <LanguageSelector 
                  currentLanguage={language} 
                  onLanguageChange={setLanguage} 
                />
                <Button onClick={() => setShowAuth(true)}>{t('nav.getStarted')}</Button>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="py-8">
          <NamecardTemplates />
        </main>
      </div>
    );
  }

  // Landing page for non-authenticated users
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                </svg>
              </div>
              <h1 className="text-xl font-bold text-gray-900">APEXCARD</h1>
            </div>
            <nav className="flex items-center space-x-6">
              <a href="/" className="text-gray-600 hover:text-blue-600 transition-colors">
                {language === 'zh-TW' ? '首頁' : language === 'zh-CN' ? '首页' : 'Home'}
              </a>
              <a href="/templates" className="text-blue-600 font-medium">
                {language === 'zh-TW' ? '名片模板' : language === 'zh-CN' ? '名片模板' : 'Templates'}
              </a>
              <a href="/scan" className="text-gray-600 hover:text-blue-600 transition-colors">
                {language === 'zh-TW' ? '名片掃描' : language === 'zh-CN' ? '名片扫描' : 'Card Scanner'}
              </a>
              <a href="/job-market" className="text-gray-600 hover:text-blue-600 transition-colors">
                {language === 'zh-TW' ? '就業市場' : language === 'zh-CN' ? '就业市场' : 'Job Market'}
              </a>
              <a href="/features" className="text-gray-600 hover:text-blue-600 transition-colors">
                {language === 'zh-TW' ? '高級功能' : language === 'zh-CN' ? '高级功能' : 'Features'}
              </a>
              <a href="/marketplace" className="text-gray-600 hover:text-blue-600 transition-colors">
                {language === 'zh-TW' ? '名片市場' : language === 'zh-CN' ? '名片市场' : 'Marketplace'}
              </a>
            </nav>
            <div className="flex items-center space-x-4">
              <LanguageSelector 
                currentLanguage={language} 
                onLanguageChange={setLanguage} 
              />
              <Button onClick={() => setShowAuth(true)}>{t('nav.getStarted')}</Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="py-8">
        <NamecardTemplates />
      </main>
    </div>
  );
}
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { auth } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    // Check authentication
    const user = await auth(request);
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const formData = await request.formData();
    const image = formData.get('image') as File;
    const cardData = formData.get('cardData') as string;

    if (!image || !cardData) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Convert image to buffer
    const imageBuffer = Buffer.from(await image.arrayBuffer());
    
    // Save image to filesystem or cloud storage (for demo, we'll use base64)
    const imageBase64 = imageBuffer.toString('base64');
    const imageUrl = `data:${image.type};base64,${imageBase64}`;

    // Parse card data from OCR result
    let parsedCardData;
    try {
      parsedCardData = JSON.parse(cardData);
    } catch (error) {
      return NextResponse.json({ error: 'Invalid card data format' }, { status: 400 });
    }

    // Save to database
    const scannedCard = await db.scannedCard.create({
      data: {
        userId: user.id,
        imageUrl: imageUrl,
        name: parsedCardData.name || '',
        company: parsedCardData.company || '',
        title: parsedCardData.title || '',
        email: parsedCardData.email || '',
        phone: parsedCardData.phone || '',
        address: parsedCardData.address || '',
        website: parsedCardData.website || '',
        notes: parsedCardData.notes || '',
        ocrData: parsedCardData,
        tags: parsedCardData.tags || []
      }
    });

    return NextResponse.json({
      success: true,
      card: scannedCard,
      message: 'Card scanned and saved successfully'
    });

  } catch (error) {
    console.error('Error scanning card:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  try {
    // Check authentication
    const user = await auth(request);
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const search = searchParams.get('search') || '';

    const skip = (page - 1) * limit;

    // Build where clause
    const where = {
      userId: user.id,
      ...(search && {
        OR: [
          { name: { contains: search, mode: 'insensitive' } },
          { company: { contains: search, mode: 'insensitive' } },
          { email: { contains: search, mode: 'insensitive' } },
          { title: { contains: search, mode: 'insensitive' } }
        ]
      })
    };

    const [cards, total] = await Promise.all([
      db.scannedCard.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit
      }),
      db.scannedCard.count({ where })
    ]);

    return NextResponse.json({
      success: true,
      cards,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Error fetching scanned cards:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
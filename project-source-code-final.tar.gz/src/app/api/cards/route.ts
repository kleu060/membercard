import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

// Helper function to get user from token
async function getUserFromToken(request: NextRequest) {
  const token = request.cookies.get('token')?.value;
  
  if (!token) {
    return null;
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { userId: string };
    const user = await db.user.findUnique({
      where: { id: decoded.userId }
    });
    
    return user;
  } catch (error) {
    return null;
  }
}

export async function GET(request: NextRequest) {
  try {
    const user = await getUserFromToken(request);
    
    if (!user) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const cards = await db.businessCard.findMany({
      where: { userId: user.id },
      include: {
        socialLinks: true,
        products: true,
        industryTags: true
      },
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json({ cards });
  } catch (error) {
    console.error('Get cards error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromToken(request);
    
    if (!user) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const {
      name,
      company,
      position,
      phone,
      officePhone,
      email,
      address,
      website,
      bio,
      avatar,
      isPublic,
      socialLinks,
      products,
      industryTags
    } = await request.json();

    // Create business card
    const card = await db.businessCard.create({
      data: {
        userId: user.id,
        name,
        company,
        position,
        phone,
        officePhone,
        email,
        address,
        website,
        bio,
        avatar,
        isPublic,
        socialLinks: {
          create: {
            data: socialLinks || []
          }
        },
        products: {
          createMany: {
            data: products || []
          }
        },
        industryTags: {
          createMany: {
            data: industryTags?.map((tag: string) => ({ tag })) || []
          }
        }
      },
      include: {
        socialLinks: true,
        products: true,
        industryTags: true
      }
    });

    return NextResponse.json({
      message: 'Business card created successfully',
      card
    });
  } catch (error) {
    console.error('Create card error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

// Helper function to get user from token
async function getUserFromToken(request: NextRequest) {
  const token = request.cookies.get('token')?.value;
  
  if (!token) {
    return null;
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { userId: string };
    const user = await db.user.findUnique({
      where: { id: decoded.userId }
    });
    
    return user;
  } catch (error) {
    return null;
  }
}

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const card = await db.businessCard.findUnique({
      where: { id: params.id },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true
          }
        },
        socialLinks: true,
        products: true,
        industryTags: true
      }
    });

    if (!card) {
      return NextResponse.json(
        { error: 'Card not found' },
        { status: 404 }
      );
    }

    // Increment view count for public cards
    if (card.isPublic) {
      await db.businessCard.update({
        where: { id: params.id },
        data: { viewCount: { increment: 1 } }
      });
    }

    return NextResponse.json({ card });
  } catch (error) {
    console.error('Get card error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await getUserFromToken(request);
    
    if (!user) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const existingCard = await db.businessCard.findUnique({
      where: { id: params.id }
    });

    if (!existingCard || existingCard.userId !== user.id) {
      return NextResponse.json(
        { error: 'Card not found or unauthorized' },
        { status: 404 }
      );
    }

    const {
      name,
      company,
      position,
      phone,
      officePhone,
      email,
      address,
      website,
      bio,
      avatar,
      isPublic,
      socialLinks,
      products,
      industryTags
    } = await request.json();

    // Update business card
    const card = await db.businessCard.update({
      where: { id: params.id },
      data: {
        name,
        company,
        position,
        phone,
        officePhone,
        email,
        address,
        website,
        bio,
        avatar,
        isPublic,
        socialLinks: {
          deleteMany: {},
          create: socialLinks || []
        },
        products: {
          deleteMany: {},
          createMany: {
            data: products || []
          }
        },
        industryTags: {
          deleteMany: {},
          createMany: {
            data: industryTags?.map((tag: string) => ({ tag })) || []
          }
        }
      },
      include: {
        socialLinks: true,
        products: true,
        industryTags: true
      }
    });

    return NextResponse.json({
      message: 'Business card updated successfully',
      card
    });
  } catch (error) {
    console.error('Update card error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await getUserFromToken(request);
    
    if (!user) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const existingCard = await db.businessCard.findUnique({
      where: { id: params.id }
    });

    if (!existingCard || existingCard.userId !== user.id) {
      return NextResponse.json(
        { error: 'Card not found or unauthorized' },
        { status: 404 }
      );
    }

    await db.businessCard.delete({
      where: { id: params.id }
    });

    return NextResponse.json({
      message: 'Business card deleted successfully'
    });
  } catch (error) {
    console.error('Delete card error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
'use client';

import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import BusinessCardDisplay from '@/components/cards/BusinessCardDisplay';
import { 
  ArrowLeft, 
  Share2, 
  Download, 
  QrCode, 
  Eye,
  Calendar,
  MapPin,
  Building2,
  Briefcase
} from 'lucide-react';
import QRCodeComponent from '@/components/ui/qr-code';

export default function PublicCardPage() {
  const params = useParams();
  const cardId = params.id as string;
  
  const [card, setCard] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showQRCode, setShowQRCode] = useState(false);

  useEffect(() => {
    fetchCard();
  }, [cardId]);

  const fetchCard = async () => {
    setLoading(true);
    setError('');

    try {
      const response = await fetch(`/api/cards/${cardId}`);
      const data = await response.json();

      if (response.ok) {
        setCard(data.card);
      } else {
        setError(data.error || '名片不存在');
      }
    } catch (error) {
      setError('网络错误');
    } finally {
      setLoading(false);
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${card.name} 的数字名片`,
          text: `${card.name} - ${card.position} at ${card.company}`,
          url: window.location.href
        });
      } catch (error) {
        console.log('分享失败');
      }
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(window.location.href);
      alert('链接已复制到剪贴板');
    }
  };

  const downloadVCard = () => {
    const vCard = `BEGIN:VCARD
VERSION:3.0
FN:${card.name}
ORG:${card.company || ''}
TITLE:${card.position || ''}
TEL:${card.phone || ''}
TEL;TYPE=WORK:${card.officePhone || ''}
EMAIL:${card.email || ''}
URL:${card.website || ''}
ADR:;;${card.address || ''};;;;
NOTE:${card.bio || ''}
END:VCARD`;

    const blob = new Blob([vCard], { type: 'text/vcard' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${card.name}.vcf`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">加载中...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="max-w-md w-full">
          <CardContent className="p-6 text-center">
            <h2 className="text-xl font-semibold text-gray-900 mb-2">名片不存在</h2>
            <p className="text-gray-600 mb-4">您访问的名片可能已被删除或不存在</p>
            <Button onClick={() => window.history.back()}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              返回
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Button 
                variant="ghost" 
                onClick={() => window.history.back()}
                className="flex items-center space-x-2"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>返回</span>
              </Button>
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <Briefcase className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-xl font-bold text-gray-900">APEXCARD</h1>
            </div>
            
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" onClick={handleShare}>
                <Share2 className="w-4 h-4 mr-2" />
                分享
              </Button>
              <Button variant="outline" size="sm" onClick={downloadVCard}>
                <Download className="w-4 h-4 mr-2" />
                保存
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setShowQRCode(true)}
              >
                <QrCode className="w-4 h-4 mr-2" />
                二维码
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Card Display */}
          <div className="lg:col-span-2">
            <BusinessCardDisplay card={card} />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Stats */}
            <Card>
              <CardContent className="p-6">
                <h3 className="font-semibold mb-4">名片统计</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Eye className="w-4 h-4 text-gray-500" />
                      <span className="text-sm">浏览次数</span>
                    </div>
                    <span className="font-semibold">{card.viewCount || 0}</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Calendar className="w-4 h-4 text-gray-500" />
                      <span className="text-sm">创建时间</span>
                    </div>
                    <span className="text-sm text-gray-600">
                      {new Date(card.createdAt).toLocaleDateString('zh-CN')}
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Briefcase className="w-4 h-4 text-gray-500" />
                      <span className="text-sm">状态</span>
                    </div>
                    <Badge variant={card.isPublic ? "default" : "secondary"}>
                      {card.isPublic ? "公开" : "私有"}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardContent className="p-6">
                <h3 className="font-semibold mb-4">快速操作</h3>
                <div className="space-y-2">
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={handleShare}
                  >
                    <Share2 className="w-4 h-4 mr-2" />
                    分享名片
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={downloadVCard}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    下载 vCard
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={() => setShowQRCode(true)}
                  >
                    <QrCode className="w-4 h-4 mr-2" />
                    显示二维码
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Location Info */}
            {card.address && (
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4 flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    位置信息
                  </h3>
                  <p className="text-sm text-gray-600">{card.address}</p>
                </CardContent>
              </Card>
            )}

            {/* Company Info */}
            {card.company && (
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4 flex items-center gap-2">
                    <Building2 className="w-4 h-4" />
                    公司信息
                  </h3>
                  <div className="space-y-2">
                    <p className="font-medium">{card.company}</p>
                    {card.position && (
                      <p className="text-sm text-gray-600">{card.position}</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>

      {/* QR Code Modal */}
      {showQRCode && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 max-w-sm w-full">
            <div className="text-center">
              <h3 className="text-lg font-semibold mb-4">扫描二维码</h3>
              <div className="bg-gray-100 p-4 rounded-lg mb-4">
                <QRCodeComponent 
                  value={window.location.href} 
                  size={192}
                  className="mx-auto"
                />
              </div>
              <p className="text-sm text-gray-600 mb-4">
                扫描二维码快速保存联系方式
              </p>
              <div className="space-y-2">
                <Button onClick={() => setShowQRCode(false)} className="w-full">
                  关闭
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => {
                    navigator.clipboard.writeText(window.location.href);
                    alert('链接已复制到剪贴板');
                  }}
                  className="w-full"
                >
                  复制链接
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
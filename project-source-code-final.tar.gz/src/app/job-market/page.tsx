'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Search, 
  MapPin, 
  Building, 
  Clock, 
  DollarSign, 
  ExternalLink,
  Filter,
  Briefcase,
  Users,
  TrendingUp,
  Calendar
} from 'lucide-react';
import LocationAutocomplete from '@/components/ui/location-autocomplete';
import { useLanguage } from '@/contexts/LanguageContext';

interface JobListing {
  id: string;
  title: string;
  company: string;
  industry: string;
  industryZh: string;
  location: string;
  type: string;
  salary: string;
  postedDate: string;
  description: string;
  requirements: string[];
  logo?: string;
  url?: string;
}

export default function JobMarketPage() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showAuth, setShowAuth] = useState(false);
  const [jobs, setJobs] = useState<JobListing[]>([]);
  const [filteredJobs, setFilteredJobs] = useState<JobListing[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedIndustry, setSelectedIndustry] = useState('');
  const [locationFilter, setLocationFilter] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const { language, t } = useLanguage();

  const industryOptions = [
    { value: 'Accounting & Finance', label: 'Accounting & Finance', labelZh: '会计与金融' },
    { value: 'Administration & Office Support', label: 'Administration & Office Support', labelZh: '行政与文职' },
    { value: 'Advertising & Media', label: 'Advertising & Media', labelZh: '廣告与媒体' },
    { value: 'Banking & Financial Services', label: 'Banking & Financial Services', labelZh: '银行与金融服务' },
    { value: 'Customer Service', label: 'Customer Service', labelZh: '客户服务' },
    { value: 'Executive Management', label: 'Executive Management', labelZh: '高管与综合管理' },
    { value: 'Nonprofit & Social Services', label: 'Nonprofit & Social Services', labelZh: '非营利与社会服务' },
    { value: 'Construction', label: 'Construction', labelZh: '建筑与工程' },
    { value: 'Business Consulting', label: 'Business Consulting', labelZh: '商业咨询与战略' },
    { value: 'Design & Architecture', label: 'Design & Architecture', labelZh: '设计与建筑' },
    { value: 'Education & Training', label: 'Education & Training', labelZh: '教育与培训' },
    { value: 'Engineering & Technical', label: 'Engineering & Technical', labelZh: '工程技术' },
    { value: 'Agriculture & Environment', label: 'Agriculture & Environment', labelZh: '农业与环保' },
    { value: 'Government & Public Sector', label: 'Government & Public Sector', labelZh: '政府与公共部门' },
    { value: 'Healthcare & Medical', label: 'Healthcare & Medical', labelZh: '医疗与健康' },
    { value: 'Hospitality & Travel', label: 'Hospitality & Travel', labelZh: '酒店与旅游' },
    { value: 'HR & Staffing', label: 'HR & Staffing', labelZh: '人力资源与招聘' },
    { value: 'Information & Technology', label: 'Information & Technology', labelZh: '資訊與技術' },
    { value: 'Insurance', label: 'Insurance', labelZh: '保险业' },
    { value: 'Legal Services', label: 'Legal Services', labelZh: '法律服务' },
    { value: 'Manufacturing & Production', label: 'Manufacturing & Production', labelZh: '制造业与生产' },
    { value: 'Transport & Logistics', label: 'Transport & Logistics', labelZh: '运输与物流' },
    { value: 'Marketing & PR', label: 'Marketing & PR', labelZh: '市场营销与公关' },
    { value: 'Mining & Energy', label: 'Mining & Energy', labelZh: '矿业与能源' },
    { value: 'Real Estate', label: 'Real Estate', labelZh: '房地产' },
    { value: 'Retail', label: 'Retail', labelZh: '零售与消费品' },
    { value: 'Sales', label: 'Sales', labelZh: '销售' },
    { value: 'Science & Research', label: 'Science & Research', labelZh: '科学与研究' },
    { value: 'Freelance & Entrepreneurship', label: 'Freelance & Entrepreneurship', labelZh: '自由职业与创业' },
    { value: 'Sports & Fitness', label: 'Sports & Fitness', labelZh: '体育与休闲' }
  ];

  useEffect(() => {
    checkAuth();
    fetchJobs();
  }, []);

  useEffect(() => {
    filterJobs();
  }, [jobs, searchTerm, selectedIndustry, locationFilter]);

  const checkAuth = async () => {
    try {
      const response = await fetch('/api/auth/me');
      if (response.ok) {
        const data = await response.json();
        setUser(data.user);
      }
    } catch (error) {
      // User not authenticated
    } finally {
      setLoading(false);
    }
  };

  const fetchJobs = async () => {
    setIsSearching(true);
    try {
      const response = await fetch('/api/jobs');
      const data = await response.json();
      
      if (response.ok) {
        setJobs(data.jobs);
      }
    } catch (error) {
      console.error('Failed to fetch jobs:', error);
      // Use mock data as fallback
      setJobs(getMockJobs());
    } finally {
      setIsSearching(false);
    }
  };

  const filterJobs = () => {
    let filtered = jobs;

    if (searchTerm) {
      filtered = filtered.filter(job =>
        job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        job.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
        job.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (selectedIndustry) {
      filtered = filtered.filter(job => 
        job.industry === selectedIndustry || job.industryZh === selectedIndustry
      );
    }

    if (locationFilter) {
      filtered = filtered.filter(job =>
        job.location.toLowerCase().includes(locationFilter.toLowerCase())
      );
    }

    setFilteredJobs(filtered);
  };

  const handleSearch = async () => {
    setIsSearching(true);
    try {
      const params = new URLSearchParams({
        ...(searchTerm && { q: searchTerm }),
        ...(selectedIndustry && { industry: selectedIndustry }),
        ...(locationFilter && { location: locationFilter })
      });

      const response = await fetch(`/api/jobs/search?${params}`);
      const data = await response.json();
      
      if (response.ok) {
        setFilteredJobs(data.jobs);
      }
    } catch (error) {
      console.error('Failed to search jobs:', error);
      filterJobs();
    } finally {
      setIsSearching(false);
    }
  };

  const getMockJobs = (): JobListing[] => {
    return [
      {
        id: '1',
        title: 'Senior Software Engineer',
        company: 'Tech Solutions Ltd',
        industry: 'Information & Technology',
        industryZh: '資訊與技術',
        location: 'Hong Kong',
        type: 'Full-time',
        salary: '$35,000 - $45,000',
        postedDate: '2024-01-15',
        description: 'We are looking for an experienced software engineer to join our dynamic team.',
        requirements: ['5+ years experience', 'React/Node.js', 'Bachelor\'s degree'],
        logo: '/api/placeholder/40/40'
      },
      {
        id: '2',
        title: 'Marketing Manager',
        company: 'Global Marketing Group',
        industry: 'Marketing & PR',
        industryZh: '市场营销与公关',
        location: 'Kowloon, Hong Kong',
        type: 'Full-time',
        salary: '$28,000 - $35,000',
        postedDate: '2024-01-14',
        description: 'Lead our marketing team and drive brand growth strategies.',
        requirements: ['8+ years experience', 'Digital marketing', 'Team leadership'],
        logo: '/api/placeholder/40/40'
      },
      {
        id: '3',
        title: 'Financial Analyst',
        company: 'Investment Bank Asia',
        industry: 'Banking & Financial Services',
        industryZh: '银行与金融服务',
        location: 'Central, Hong Kong',
        type: 'Full-time',
        salary: '$30,000 - $40,000',
        postedDate: '2024-01-13',
        description: 'Analyze financial data and provide investment recommendations.',
        requirements: ['CFA preferred', '3+ years experience', 'Excel expert'],
        logo: '/api/placeholder/40/40'
      },
      {
        id: '4',
        title: 'UX Designer',
        company: 'Creative Digital Agency',
        industry: 'Design & Architecture',
        industryZh: '设计与建筑',
        location: 'Hong Kong',
        type: 'Full-time',
        salary: '$25,000 - $32,000',
        postedDate: '2024-01-12',
        description: 'Create amazing user experiences for web and mobile applications.',
        requirements: ['Figma proficiency', '3+ years experience', 'Portfolio required'],
        logo: '/api/placeholder/40/40'
      },
      {
        id: '5',
        title: 'Sales Executive',
        company: 'Sales Pro Limited',
        industry: 'Sales',
        industryZh: '销售',
        location: 'Tsim Sha Tsui, Hong Kong',
        type: 'Full-time',
        salary: '$20,000 - $25,000 + Commission',
        postedDate: '2024-01-11',
        description: 'Drive sales growth and build client relationships.',
        requirements: ['Sales experience', 'Communication skills', 'Target-driven'],
        logo: '/api/placeholder/40/40'
      }
    ];
  };

  const getLocalizedTexts = () => {
    const texts = {
      'zh-TW': {
        title: '就業市場',
        subtitle: '搜尋香港及全球的工作機會',
        searchPlaceholder: '輸入職位關鍵字...',
        industryPlaceholder: '選擇行業...',
        locationPlaceholder: '輸入地區...',
        searchButton: '搜尋工作',
        clearFilters: '清除篩選',
        results: '找到 {count} 個工作機會',
        jobType: '工作類型',
        salary: '薪資',
        location: '地點',
        posted: '發布日期',
        requirements: '職位要求',
        apply: '申請職位',
        viewDetails: '查看詳情',
        noJobs: '沒有找到符合條件的工作',
        loading: '載入中...',
        industry: '行業',
        location: '地區'
      },
      'zh-CN': {
        title: '就业市场',
        subtitle: '搜索香港及全球的工作机会',
        searchPlaceholder: '输入职位关键字...',
        industryPlaceholder: '选择行业...',
        locationPlaceholder: '输入地区...',
        searchButton: '搜索工作',
        clearFilters: '清除筛选',
        results: '找到 {count} 个工作机会',
        jobType: '工作类型',
        salary: '薪资',
        location: '地点',
        posted: '发布日期',
        requirements: '职位要求',
        apply: '申请职位',
        viewDetails: '查看详情',
        noJobs: '没有找到符合条件的工作',
        loading: '加载中...',
        industry: '行业',
        location: '地区'
      },
      'en': {
        title: 'Job Market',
        subtitle: 'Search job opportunities in Hong Kong and worldwide',
        searchPlaceholder: 'Enter job keywords...',
        industryPlaceholder: 'Select industry...',
        locationPlaceholder: 'Enter location...',
        searchButton: 'Search Jobs',
        clearFilters: 'Clear Filters',
        results: 'Found {count} job opportunities',
        jobType: 'Job Type',
        salary: 'Salary',
        location: 'Location',
        posted: 'Posted',
        requirements: 'Requirements',
        apply: 'Apply Now',
        viewDetails: 'View Details',
        noJobs: 'No jobs found matching your criteria',
        loading: 'Loading...',
        industry: 'Industry',
        location: 'Location'
      }
    };

    return texts[language as keyof typeof texts] || texts['en'];
  };

  const texts = getLocalizedTexts();

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">{texts.loading}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <Briefcase className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-xl font-bold text-gray-900">APEXCARD</h1>
            </div>
            <nav className="flex items-center space-x-6">
              <a href="/" className="text-gray-600 hover:text-blue-600 transition-colors">
                {language === 'zh-TW' ? '首頁' : language === 'zh-CN' ? '首页' : 'Home'}
              </a>
              <a href="/templates" className="text-gray-600 hover:text-blue-600 transition-colors">
                {language === 'zh-TW' ? '名片模板' : language === 'zh-CN' ? '名片模板' : 'Templates'}
              </a>
              <a href="/job-market" className="text-blue-600 font-medium">
                {texts.title}
              </a>
              <a href="/marketplace" className="text-gray-600 hover:text-blue-600 transition-colors">
                {language === 'zh-TW' ? '名片市場' : language === 'zh-CN' ? '名片市场' : 'Marketplace'}
              </a>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">{texts.title}</h1>
            <p className="text-xl text-blue-100 mb-8">{texts.subtitle}</p>
          </div>
        </div>
      </section>

      {/* Search Filters */}
      <section className="py-8 bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-4">
            {/* Job Title Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder={texts.searchPlaceholder}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              />
            </div>

            {/* Industry Dropdown */}
            <select
              value={selectedIndustry}
              onChange={(e) => setSelectedIndustry(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">{texts.industryPlaceholder}</option>
              {industryOptions.map((industry) => (
                <option key={industry.value} value={industry.value}>
                  {language === 'zh-TW' || language === 'zh-CN' 
                    ? `${industry.labelZh} (${industry.label})`
                    : `${industry.label} (${industry.labelZh})`
                  }
                </option>
              ))}
            </select>

            {/* Location Filter */}
            <LocationAutocomplete
              value={locationFilter}
              onChange={setLocationFilter}
              placeholder={texts.locationPlaceholder}
              className="w-full"
            />

            {/* Search Button */}
            <Button 
              onClick={handleSearch}
              disabled={isSearching}
              className="w-full"
            >
              {isSearching ? texts.loading : texts.searchButton}
            </Button>
          </div>

          {/* Active Filters */}
          {(searchTerm || selectedIndustry || locationFilter) && (
            <div className="mt-4 flex items-center space-x-2">
              <span className="text-sm text-gray-600">Active filters:</span>
              {searchTerm && (
                <Badge variant="secondary" className="flex items-center space-x-1">
                  <span>{searchTerm}</span>
                  <button 
                    onClick={() => setSearchTerm('')}
                    className="ml-1 text-xs"
                  >
                    ×
                  </button>
                </Badge>
              )}
              {selectedIndustry && (
                <Badge variant="secondary" className="flex items-center space-x-1">
                  <span>
                    {industryOptions.find(i => i.value === selectedIndustry)?.labelZh || selectedIndustry}
                  </span>
                  <button 
                    onClick={() => setSelectedIndustry('')}
                    className="ml-1 text-xs"
                  >
                    ×
                  </button>
                </Badge>
              )}
              {locationFilter && (
                <Badge variant="secondary" className="flex items-center space-x-1">
                  <span>{locationFilter}</span>
                  <button 
                    onClick={() => setLocationFilter('')}
                    className="ml-1 text-xs"
                  >
                    ×
                  </button>
                </Badge>
              )}
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => {
                  setSearchTerm('');
                  setSelectedIndustry('');
                  setLocationFilter('');
                }}
              >
                {texts.clearFilters}
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* Results Section */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              {texts.results.replace('{count}', filteredJobs.length.toString())}
            </h2>
          </div>

          {isSearching ? (
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-6">
                    <div className="h-6 bg-gray-200 rounded w-3/4 mb-4"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/2 mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/3"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : filteredJobs.length > 0 ? (
            <div className="space-y-4">
              {filteredJobs.map((job) => (
                <Card key={job.id} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <div className="w-10 h-10 bg-gray-200 rounded-lg flex items-center justify-center">
                            <Building className="w-5 h-5 text-gray-500" />
                          </div>
                          <div>
                            <h3 className="text-lg font-semibold text-gray-900">{job.title}</h3>
                            <p className="text-sm text-gray-600">{job.company}</p>
                          </div>
                        </div>
                        
                        <div className="flex flex-wrap items-center space-x-4 text-sm text-gray-600 mb-3">
                          <div className="flex items-center space-x-1">
                            <MapPin className="w-4 h-4" />
                            <span>{job.location}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <DollarSign className="w-4 h-4" />
                            <span>{job.salary}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Clock className="w-4 h-4" />
                            <span>{job.type}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Calendar className="w-4 h-4" />
                            <span>{new Date(job.postedDate).toLocaleDateString()}</span>
                          </div>
                        </div>

                        <div className="flex flex-wrap gap-2 mb-3">
                          <Badge variant="outline">
                            {language === 'zh-TW' || language === 'zh-CN' ? job.industryZh : job.industry}
                          </Badge>
                        </div>

                        <p className="text-gray-600 mb-3">{job.description}</p>
                        
                        <div className="mb-4">
                          <h4 className="font-medium text-gray-900 mb-2">{texts.requirements}:</h4>
                          <div className="flex flex-wrap gap-2">
                            {job.requirements.map((req, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {req}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                      
                      <div className="ml-6 flex flex-col space-y-2">
                        <Button size="sm">
                          {texts.apply}
                        </Button>
                        <Button variant="outline" size="sm">
                          {texts.viewDetails}
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Briefcase className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{texts.noJobs}</h3>
                <p className="text-gray-600 mb-4">
                  Try adjusting your search criteria or browse all available positions
                </p>
                <Button onClick={() => {
                  setSearchTerm('');
                  setSelectedIndustry('');
                  setLocationFilter('');
                }}>
                  {texts.clearFilters}
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </section>
    </div>
  );
}
import { PayPalEnvironment, PayPalHttpClient } from '@paypal/paypal-server-sdk';

interface PayPalConfig {
  clientId: string;
  clientSecret: string;
  environment: 'sandbox' | 'live';
}

class PayPalService {
  private client: PayPalHttpClient;

  constructor(config: PayPalConfig) {
    const environment = config.environment === 'live' 
      ? new PayPalEnvironment.Live(config.clientId, config.clientSecret)
      : new PayPalEnvironment.Sandbox(config.clientId, config.clientSecret);
    
    this.client = new PayPalHttpClient(environment);
  }

  async createOrder(amount: string, currency: string = 'USD', description?: string) {
    try {
      const request = {
        intent: 'CAPTURE',
        purchase_units: [
          {
            amount: {
              currency_code: currency,
              value: amount,
            },
            description: description || 'Payment for service',
          },
        ],
      };

      const order = await this.client.execute({
        method: 'POST',
        path: '/v2/checkout/orders',
        body: request,
      });

      return order.result;
    } catch (error) {
      console.error('PayPal create order error:', error);
      throw new Error('Failed to create PayPal order');
    }
  }

  async captureOrder(orderId: string) {
    try {
      const request = {};

      const capture = await this.client.execute({
        method: 'POST',
        path: `/v2/checkout/orders/${orderId}/capture`,
        body: request,
      });

      return capture.result;
    } catch (error) {
      console.error('PayPal capture order error:', error);
      throw new Error('Failed to capture PayPal order');
    }
  }

  async getOrderDetails(orderId: string) {
    try {
      const order = await this.client.execute({
        method: 'GET',
        path: `/v2/checkout/orders/${orderId}`,
      });

      return order.result;
    } catch (error) {
      console.error('PayPal get order details error:', error);
      throw new Error('Failed to get PayPal order details');
    }
  }

  async createWebhook(url: string, eventTypes: string[] = []) {
    try {
      const defaultEventTypes = [
        'PAYMENT.AUTHORIZATION.CREATED',
        'PAYMENT.AUTHORIZATION.VOIDED',
        'PAYMENT.CAPTURE.COMPLETED',
        'PAYMENT.CAPTURE.DENIED',
        'PAYMENT.CAPTURE.PENDING',
        'PAYMENT.CAPTURE.REFUNDED',
        'PAYMENT.CAPTURE.REVERSED',
        'PAYMENT.SALE.COMPLETED',
        'PAYMENT.SALE.DENIED',
        'PAYMENT.SALE.PENDING',
        'PAYMENT.SALE.REFUNDED',
        'PAYMENT.SALE.REVERSED',
      ];

      const webhookEvents = eventTypes.length > 0 ? eventTypes : defaultEventTypes;

      const request = {
        url: url,
        event_types: webhookEvents.map(eventType => ({ name: eventType })),
      };

      const webhook = await this.client.execute({
        method: 'POST',
        path: '/v1/notifications/webhooks',
        body: request,
      });

      return webhook.result;
    } catch (error) {
      console.error('PayPal create webhook error:', error);
      throw new Error('Failed to create PayPal webhook');
    }
  }

  async verifyWebhookSignature(headers: any, body: any) {
    try {
      const request = {
        transmission_id: headers['paypal-transmission-id'],
        cert_url: headers['paypal-cert-url'],
        auth_algo: headers['paypal-auth-algo'],
        transmission_sig: headers['paypal-transmission-sig'],
        transmission_time: headers['paypal-transmission-time'],
        webhook_id: process.env.PAYPAL_WEBHOOK_ID,
        webhook_event: body,
      };

      const verification = await this.client.execute({
        method: 'POST',
        path: '/v1/notifications/verify-webhook-signature',
        body: request,
      });

      return verification.result;
    } catch (error) {
      console.error('PayPal verify webhook signature error:', error);
      throw new Error('Failed to verify PayPal webhook signature');
    }
  }
}

// Create singleton instance
let paypalService: PayPalService | null = null;

export function getPayPalService(): PayPalService {
  if (!paypalService) {
    const config: PayPalConfig = {
      clientId: process.env.PAYPAL_CLIENT_ID!,
      clientSecret: process.env.PAYPAL_CLIENT_SECRET!,
      environment: (process.env.PAYPAL_ENVIRONMENT as 'sandbox' | 'live') || 'sandbox',
    };

    if (!config.clientId || !config.clientSecret) {
      throw new Error('PayPal configuration is missing. Please set PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET environment variables.');
    }

    paypalService = new PayPalService(config);
  }

  return paypalService;
}

export { PayPalService };
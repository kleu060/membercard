'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  User, 
  Building2, 
  Briefcase, 
  Phone, 
  Mail, 
  MapPin, 
  Globe, 
  Plus, 
  X,
  Image as ImageIcon,
  Save,
  Eye,
  EyeOff
} from 'lucide-react';

interface BusinessCardFormProps {
  card?: any;
  onSave?: (card: any) => void;
  onCancel?: () => void;
}

const industryOptions = [
  "全部名片 (All Industries)",
  "房地產業務 (Real Estate)",
  "汽車銷售 (Automotive Sales)",
  "金融保險 (Finance & Insurance)",
  "醫療健康 (Healthcare)",
  "家居維修 (Residential Maintenance)",
  "物流倉儲 (Logistics & Warehousing)",
  "教育與輔導 (Education and Tutoring)",
  "美容護理 (Beauty & Haircare)",
  "旅遊導覽 (Tourism Services)",
  "餐飲與住宿 (Dining and Accommodation)",
  "製造業 (Manufacturing)",
  "批發與零售 (Wholesale & Retail)",
  "資訊技術 (Information Technology)",
  "媒體製作 (Media Production)",
  "行銷與內容 (Marketing & Content)",
  "娛樂產業 (Entertainment)",
  "創意設計 (Creative Design)",
  "法律與會計 (Legal & Accounting)",
  "建築工程 (Construction)",
  "農業與畜牧 (Agriculture & Livestock)",
  "其他服務業 (Other Services)"
];

const socialPlatforms = [
  { value: 'linkedin', label: 'LinkedIn' },
  { value: 'facebook', label: 'Facebook' },
  { value: 'instagram', label: 'Instagram' },
  { value: 'twitter', label: 'Twitter' },
  { value: 'wechat', label: '微信' },
  { value: 'line', label: 'LINE' },
  { value: 'website', label: '个人网站' },
  { value: 'other', label: '其他' }
];

export default function BusinessCardForm({ card, onSave, onCancel }: BusinessCardFormProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    name: card?.name || '',
    company: card?.company || '',
    position: card?.position || '',
    phone: card?.phone || '',
    officePhone: card?.officePhone || '',
    email: card?.email || '',
    address: card?.address || '',
    website: card?.website || '',
    bio: card?.bio || '',
    avatar: card?.avatar || '',
    isPublic: card?.isPublic ?? true,
    socialLinks: card?.socialLinks || [],
    products: card?.products || [],
    industryTags: card?.industryTags?.map((tag: any) => tag.tag) || []
  });

  const [newSocialLink, setNewSocialLink] = useState({ platform: '', url: '', username: '' });
  const [newProduct, setNewProduct] = useState({ name: '', description: '', image: '' });

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const addSocialLink = () => {
    if (newSocialLink.platform && newSocialLink.url) {
      setFormData(prev => ({
        ...prev,
        socialLinks: [...prev.socialLinks, newSocialLink]
      }));
      setNewSocialLink({ platform: '', url: '', username: '' });
    }
  };

  const removeSocialLink = (index: number) => {
    setFormData(prev => ({
      ...prev,
      socialLinks: prev.socialLinks.filter((_, i) => i !== index)
    }));
  };

  const addProduct = () => {
    if (newProduct.name) {
      setFormData(prev => ({
        ...prev,
        products: [...prev.products, newProduct]
      }));
      setNewProduct({ name: '', description: '', image: '' });
    }
  };

  const removeProduct = (index: number) => {
    setFormData(prev => ({
      ...prev,
      products: prev.products.filter((_, i) => i !== index)
    }));
  };

  const toggleIndustryTag = (tag: string) => {
    // Don't allow selecting "全部名片" (All Industries) as it's just for filtering
    if (tag.includes("全部名片") || tag.includes("All Industries")) {
      return;
    }
    
    setFormData(prev => ({
      ...prev,
      industryTags: prev.industryTags.includes(tag)
        ? prev.industryTags.filter(t => t !== tag)
        : [...prev.industryTags, tag].slice(0, 3) // Limit to 3 tags
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      const url = card ? `/api/cards/${card.id}` : '/api/cards';
      const method = card ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      const data = await response.json();

      if (response.ok) {
        onSave?.(data.card);
      } else {
        setError(data.error || '保存失败');
      }
    } catch (error) {
      setError('网络错误');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Briefcase className="w-5 h-5" />
            {card ? '编辑名片' : '创建新名片'}
          </CardTitle>
          <CardDescription>
            填写您的个人信息，创建专业的数字名片
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {/* Basic Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">基本信息</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">姓名 *</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => handleInputChange('name', e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="company">公司</Label>
                  <div className="relative">
                    <Building2 className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="company"
                      value={formData.company}
                      onChange={(e) => handleInputChange('company', e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="position">职位</Label>
                  <div className="relative">
                    <Briefcase className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="position"
                      value={formData.position}
                      onChange={(e) => handleInputChange('position', e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">手机号码</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => handleInputChange('phone', e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="officePhone">办公电话</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="officePhone"
                      value={formData.officePhone}
                      onChange={(e) => handleInputChange('officePhone', e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">邮箱</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="website">个人网站</Label>
                  <div className="relative">
                    <Globe className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="website"
                      value={formData.website}
                      onChange={(e) => handleInputChange('website', e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="avatar">头像链接</Label>
                  <div className="relative">
                    <ImageIcon className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="avatar"
                      value={formData.avatar}
                      onChange={(e) => handleInputChange('avatar', e.target.value)}
                      className="pl-10"
                      placeholder="https://example.com/avatar.jpg"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="address">地址</Label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="address"
                    value={formData.address}
                    onChange={(e) => handleInputChange('address', e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="bio">个人简介</Label>
                <Textarea
                  id="bio"
                  value={formData.bio}
                  onChange={(e) => handleInputChange('bio', e.target.value)}
                  placeholder="简单介绍一下自己..."
                  rows={3}
                />
              </div>
            </div>

            {/* Social Links */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">社交媒体链接</h3>
              <div className="space-y-3">
                {formData.socialLinks.map((link: any, index: number) => (
                  <div key={index} className="flex items-center gap-2">
                    <Select value={link.platform} onValueChange={(value) => {
                      const newLinks = [...formData.socialLinks];
                      newLinks[index].platform = value;
                      handleInputChange('socialLinks', newLinks);
                    }}>
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {socialPlatforms.map(platform => (
                          <SelectItem key={platform.value} value={platform.value}>
                            {platform.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Input
                      value={link.url}
                      onChange={(e) => {
                        const newLinks = [...formData.socialLinks];
                        newLinks[index].url = e.target.value;
                        handleInputChange('socialLinks', newLinks);
                      }}
                      placeholder="链接地址"
                      className="flex-1"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={() => removeSocialLink(index)}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
                
                <div className="flex items-center gap-2">
                  <Select value={newSocialLink.platform} onValueChange={(value) => setNewSocialLink({ ...newSocialLink, platform: value })}>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="选择平台" />
                    </SelectTrigger>
                    <SelectContent>
                      {socialPlatforms.map(platform => (
                        <SelectItem key={platform.value} value={platform.value}>
                          {platform.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Input
                    value={newSocialLink.url}
                    onChange={(e) => setNewSocialLink({ ...newSocialLink, url: e.target.value })}
                    placeholder="链接地址"
                    className="flex-1"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    onClick={addSocialLink}
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Products */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">产品/服务展示</h3>
              <div className="space-y-3">
                {formData.products.map((product: any, index: number) => (
                  <div key={index} className="border rounded-lg p-4">
                    <div className="flex justify-between items-start mb-2">
                      <Input
                        value={product.name}
                        onChange={(e) => {
                          const newProducts = [...formData.products];
                          newProducts[index].name = e.target.value;
                          handleInputChange('products', newProducts);
                        }}
                        placeholder="产品名称"
                        className="font-semibold"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        onClick={() => removeProduct(index)}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                    <Textarea
                      value={product.description}
                      onChange={(e) => {
                        const newProducts = [...formData.products];
                        newProducts[index].description = e.target.value;
                        handleInputChange('products', newProducts);
                      }}
                      placeholder="产品描述"
                      rows={2}
                    />
                    <Input
                      value={product.image}
                      onChange={(e) => {
                        const newProducts = [...formData.products];
                        newProducts[index].image = e.target.value;
                        handleInputChange('products', newProducts);
                      }}
                      placeholder="产品图片链接"
                      className="mt-2"
                    />
                  </div>
                ))}
                
                {formData.products.length < 3 && (
                  <Button
                    type="button"
                    variant="outline"
                    onClick={addProduct}
                    className="w-full"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    添加产品/服务
                  </Button>
                )}
              </div>
            </div>

            {/* Industry Tags */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold">行业标签</h3>
                <span className="text-sm text-gray-500">
                  已选择 {formData.industryTags.length}/3 个
                </span>
              </div>
              <p className="text-sm text-gray-600">请选择最能代表您业务的行业标签（最多3个）</p>
              <div className="flex flex-wrap gap-2">
                {industryOptions.map((industry) => {
                  const isAllIndustries = industry.includes("全部名片") || industry.includes("All Industries");
                  const isSelected = formData.industryTags.includes(industry);
                  const isDisabled = isAllIndustries || (!isSelected && formData.industryTags.length >= 3);
                  
                  return (
                    <Badge
                      key={industry}
                      variant={isSelected ? "default" : "outline"}
                      className={`cursor-pointer transition-all ${
                        isDisabled ? 'opacity-50 cursor-not-allowed' : 'hover:bg-gray-100'
                      }`}
                      onClick={() => !isDisabled && toggleIndustryTag(industry)}
                    >
                      {industry.split(' ')[0]}
                    </Badge>
                  );
                })}
              </div>
              {formData.industryTags.length >= 3 && (
                <p className="text-sm text-blue-600">
                  已达到最大标签数量限制，如需更改请先取消已选择的标签
                </p>
              )}
            </div>

            {/* Privacy Settings */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">隐私设置</h3>
              <div className="flex items-center space-x-2">
                <Switch
                  id="isPublic"
                  checked={formData.isPublic}
                  onCheckedChange={(checked) => handleInputChange('isPublic', checked)}
                />
                <Label htmlFor="isPublic" className="flex items-center gap-2">
                  {formData.isPublic ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  公开名片 (其他人可以在市场中看到)
                </Label>
              </div>
            </div>

            {/* Actions */}
            <div className="flex justify-end space-x-4 pt-6 border-t">
              {onCancel && (
                <Button type="button" variant="outline" onClick={onCancel}>
                  取消
                </Button>
              )}
              <Button type="submit" disabled={isLoading}>
                <Save className="w-4 h-4 mr-2" />
                {isLoading ? '保存中...' : '保存名片'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  User, 
  Building2, 
  Briefcase, 
  Phone, 
  Mail, 
  MapPin, 
  Globe, 
  Share2,
  Download,
  QrCode,
  Eye,
  Calendar,
  MessageCircle,
  ExternalLink
} from 'lucide-react';
import QRCodeComponent from '@/components/ui/qr-code';

interface BusinessCardDisplayProps {
  card: any;
  isOwner?: boolean;
  onEdit?: () => void;
  onShare?: () => void;
  onSave?: () => void;
}

export default function BusinessCardDisplay({ 
  card, 
  isOwner = false, 
  onEdit, 
  onShare, 
  onSave 
}: BusinessCardDisplayProps) {
  const [showQRCode, setShowQRCode] = useState(false);

  const getSocialIcon = (platform: string) => {
    const icons: { [key: string]: string } = {
      linkedin: '🔗',
      facebook: '📘',
      instagram: '📷',
      twitter: '🐦',
      wechat: '💬',
      line: '🟢',
      website: '🌐',
      other: '🔗'
    };
    return icons[platform] || '🔗';
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${card.name} 的数字名片`,
          text: `${card.name} - ${card.position} at ${card.company}`,
          url: window.location.href
        });
      } catch (error) {
        console.log('分享失败');
      }
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(window.location.href);
      alert('链接已复制到剪贴板');
    }
  };

  const downloadVCard = () => {
    const vCard = `BEGIN:VCARD
VERSION:3.0
FN:${card.name}
ORG:${card.company || ''}
TITLE:${card.position || ''}
TEL:${card.phone || ''}
TEL;TYPE=WORK:${card.officePhone || ''}
EMAIL:${card.email || ''}
URL:${card.website || ''}
ADR:;;${card.address || ''};;;;
NOTE:${card.bio || ''}
END:VCARD`;

    const blob = new Blob([vCard], { type: 'text/vcard' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${card.name}.vcf`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-2xl mx-auto">
      <Card className="overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-6 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              {card.avatar ? (
                <img 
                  src={card.avatar} 
                  alt={card.name}
                  className="w-16 h-16 rounded-full border-2 border-white"
                />
              ) : (
                <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center">
                  <User className="w-8 h-8" />
                </div>
              )}
              <div>
                <h1 className="text-2xl font-bold">{card.name}</h1>
                {card.position && <p className="text-blue-100">{card.position}</p>}
                {card.company && <p className="text-blue-100">{card.company}</p>}
              </div>
            </div>
            <div className="flex items-center space-x-2">
              {card.viewCount !== undefined && (
                <div className="flex items-center space-x-1 text-sm">
                  <Eye className="w-4 h-4" />
                  <span>{card.viewCount}</span>
                </div>
              )}
              {isOwner && onEdit && (
                <Button variant="secondary" size="sm" onClick={onEdit}>
                  编辑
                </Button>
              )}
            </div>
          </div>
        </div>

        <CardContent className="p-6">
          {/* Contact Information */}
          <div className="space-y-4 mb-6">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <MessageCircle className="w-5 h-5" />
              联系方式
            </h2>
            
            <div className="grid gap-3">
              {card.phone && (
                <div className="flex items-center space-x-3">
                  <Phone className="w-4 h-4 text-gray-500" />
                  <span>{card.phone}</span>
                </div>
              )}
              
              {card.officePhone && (
                <div className="flex items-center space-x-3">
                  <Phone className="w-4 h-4 text-gray-500" />
                  <span>{card.officePhone} (办公)</span>
                </div>
              )}
              
              {card.email && (
                <div className="flex items-center space-x-3">
                  <Mail className="w-4 h-4 text-gray-500" />
                  <a 
                    href={`mailto:${card.email}`} 
                    className="text-blue-600 hover:underline"
                  >
                    {card.email}
                  </a>
                </div>
              )}
              
              {card.website && (
                <div className="flex items-center space-x-3">
                  <Globe className="w-4 h-4 text-gray-500" />
                  <a 
                    href={card.website} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:underline flex items-center gap-1"
                  >
                    {card.website}
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              )}
              
              {card.address && (
                <div className="flex items-center space-x-3">
                  <MapPin className="w-4 h-4 text-gray-500" />
                  <span>{card.address}</span>
                </div>
              )}
            </div>
          </div>

          {/* Social Links */}
          {card.socialLinks && card.socialLinks.length > 0 && (
            <div className="space-y-4 mb-6">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <Share2 className="w-5 h-5" />
                社交媒体
              </h2>
              <div className="flex flex-wrap gap-2">
                {card.socialLinks.map((link: any, index: number) => (
                  <a
                    key={index}
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center space-x-2 px-3 py-2 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
                  >
                    <span>{getSocialIcon(link.platform)}</span>
                    <span className="text-sm font-medium">{link.platform}</span>
                  </a>
                ))}
              </div>
            </div>
          )}

          {/* Products */}
          {card.products && card.products.length > 0 && (
            <div className="space-y-4 mb-6">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <Briefcase className="w-5 h-5" />
                产品/服务
              </h2>
              <div className="grid gap-4">
                {card.products.map((product: any, index: number) => (
                  <div key={index} className="border rounded-lg p-4">
                    <h3 className="font-semibold mb-2">{product.name}</h3>
                    {product.description && (
                      <p className="text-gray-600 text-sm mb-2">{product.description}</p>
                    )}
                    {product.image && (
                      <img 
                        src={product.image} 
                        alt={product.name}
                        className="w-full h-32 object-cover rounded-md"
                      />
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Industry Tags */}
          {card.industryTags && card.industryTags.length > 0 && (
            <div className="space-y-4 mb-6">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <Building2 className="w-5 h-5" />
                行业标签
              </h2>
              <div className="flex flex-wrap gap-2">
                {card.industryTags.map((tag: any, index: number) => (
                  <Badge key={index} variant="secondary">
                    {tag.tag}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Bio */}
          {card.bio && (
            <div className="space-y-4 mb-6">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <User className="w-5 h-5" />
                个人简介
              </h2>
              <p className="text-gray-600 leading-relaxed">{card.bio}</p>
            </div>
          )}

          {/* Actions */}
          <div className="flex flex-wrap gap-3 pt-4 border-t">
            <Button onClick={handleShare} variant="outline">
              <Share2 className="w-4 h-4 mr-2" />
              分享
            </Button>
            
            <Button onClick={downloadVCard} variant="outline">
              <Download className="w-4 h-4 mr-2" />
              保存到通讯录
            </Button>
            
            <Button 
              onClick={() => setShowQRCode(!showQRCode)} 
              variant="outline"
            >
              <QrCode className="w-4 h-4 mr-2" />
              二维码
            </Button>
            
            {onSave && (
              <Button onClick={onSave} variant="outline">
                <Download className="w-4 h-4 mr-2" />
                收藏名片
              </Button>
            )}
          </div>

          {/* QR Code Modal */}
          {showQRCode && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
              <div className="bg-white rounded-lg p-6 max-w-sm w-full">
                <div className="text-center">
                  <h3 className="text-lg font-semibold mb-4">扫描二维码</h3>
                  <div className="bg-gray-100 p-4 rounded-lg mb-4">
                    <QRCodeComponent 
                      value={window.location.href} 
                      size={192}
                      className="mx-auto"
                    />
                  </div>
                  <p className="text-sm text-gray-600 mb-4">
                    扫描二维码快速保存联系方式
                  </p>
                  <Button onClick={() => setShowQRCode(false)}>
                    关闭
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Created Date */}
          {card.createdAt && (
            <div className="flex items-center justify-center pt-4 text-sm text-gray-500">
              <Calendar className="w-4 h-4 mr-1" />
              创建于 {new Date(card.createdAt).toLocaleDateString('zh-CN')}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
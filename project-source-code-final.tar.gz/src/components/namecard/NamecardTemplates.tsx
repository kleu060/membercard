'use client';

import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  User, 
  Briefcase, 
  MapPin, 
  Phone, 
  Mail, 
  Globe, 
  Building,
  Check
} from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

interface Template {
  id: string;
  name: string;
  nameZh: string;
  description: string;
  descriptionZh: string;
  category: string;
  categoryZh: string;
  preview: {
    name: string;
    title: string;
    company: string;
    location: string;
    contact: string;
    email: string;
    website: string;
  };
  style: {
    background: string;
    textColor: string;
    accentColor: string;
    layout: 'modern' | 'classic' | 'minimal' | 'creative' | 'professional' | 'elegant';
  };
}

export default function NamecardTemplates() {
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const { language } = useLanguage();

  const templates: Template[] = [
    {
      id: 'modern-blue',
      name: 'Modern Blue',
      nameZh: '现代蓝色',
      description: 'Clean and professional with a modern blue gradient',
      descriptionZh: '简洁专业，现代蓝色渐变设计',
      category: 'Business',
      categoryZh: '商务',
      preview: {
        name: 'John Smith',
        title: 'Marketing Director',
        company: 'Tech Solutions Ltd',
        location: 'Hong Kong',
        contact: '+852 1234 5678',
        email: 'john@techsolutions.com',
        website: 'www.techsolutions.com'
      },
      style: {
        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        textColor: 'text-white',
        accentColor: 'bg-blue-200',
        layout: 'modern'
      }
    },
    {
      id: 'classic-black',
      name: 'Classic Black',
      nameZh: '经典黑色',
      description: 'Timeless elegant design with black and gold accents',
      descriptionZh: '永恒优雅设计，黑色与金色点缀',
      category: 'Executive',
      categoryZh: '高管',
      preview: {
        name: 'Emma Wilson',
        title: 'CEO',
        company: 'Global Investments',
        location: 'Central, HK',
        contact: '+852 2345 6789',
        email: 'emma@globalinvest.com',
        website: 'www.globalinvest.com'
      },
      style: {
        background: 'linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%)',
        textColor: 'text-white',
        accentColor: 'bg-yellow-400',
        layout: 'classic'
      }
    },
    {
      id: 'minimal-white',
      name: 'Minimal White',
      nameZh: '极简白色',
      description: 'Clean minimalist design with plenty of white space',
      descriptionZh: '简洁极简设计，大量留白空间',
      category: 'Creative',
      categoryZh: '创意',
      preview: {
        name: 'Alex Chen',
        title: 'UX Designer',
        company: 'Creative Studio',
        location: 'Wan Chai, HK',
        contact: '+852 3456 7890',
        email: 'alex@creativestudio.com',
        website: 'www.creativestudio.com'
      },
      style: {
        background: 'linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%)',
        textColor: 'text-gray-900',
        accentColor: 'bg-gray-200',
        layout: 'minimal'
      }
    },
    {
      id: 'creative-gradient',
      name: 'Creative Gradient',
      nameZh: '创意渐变',
      description: 'Vibrant gradient design for creative professionals',
      descriptionZh: '活力渐变设计，适合创意专业人士',
      category: 'Design',
      categoryZh: '设计',
      preview: {
        name: 'Sofia Rodriguez',
        title: 'Art Director',
        company: 'Design Agency',
        location: 'Sheung Wan, HK',
        contact: '+852 4567 8901',
        email: 'sofia@designagency.com',
        website: 'www.designagency.com'
      },
      style: {
        background: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
        textColor: 'text-white',
        accentColor: 'bg-pink-200',
        layout: 'creative'
      }
    },
    {
      id: 'professional-gray',
      name: 'Professional Gray',
      nameZh: '专业灰色',
      description: 'Corporate style with subtle gray tones',
      descriptionZh: '企业风格，低调灰色调',
      category: 'Corporate',
      categoryZh: '企业',
      preview: {
        name: 'Michael Wong',
        title: 'Financial Advisor',
        company: 'Wealth Management',
        location: 'Tsim Sha Tsui, HK',
        contact: '+852 5678 9012',
        email: 'michael@wealthmgmt.com',
        website: 'www.wealthmgmt.com'
      },
      style: {
        background: 'linear-gradient(135deg, #4b5563 0%, #6b7280 100%)',
        textColor: 'text-white',
        accentColor: 'bg-gray-300',
        layout: 'professional'
      }
    },
    {
      id: 'elegant-teal',
      name: 'Elegant Teal',
      nameZh: '优雅青色',
      description: 'Sophisticated teal with elegant typography',
      descriptionZh: '精致青色，优雅排版设计',
      category: 'Luxury',
      categoryZh: '奢侈',
      preview: {
        name: 'Isabella Liu',
        title: 'Brand Manager',
        company: 'Luxury Brands Group',
        location: 'Causeway Bay, HK',
        contact: '+852 6789 0123',
        email: 'isabella@luxurybrands.com',
        website: 'www.luxurybrands.com'
      },
      style: {
        background: 'linear-gradient(135deg, #14b8a6 0%, #0d9488 100%)',
        textColor: 'text-white',
        accentColor: 'bg-teal-200',
        layout: 'elegant'
      }
    }
  ];

  const handleSelectTemplate = (templateId: string) => {
    setSelectedTemplate(templateId);
  };

  const handleUseTemplate = () => {
    if (selectedTemplate) {
      // Here you would typically navigate to the card creation page with the selected template
      const template = templates.find(t => t.id === selectedTemplate);
      if (template) {
        // For now, we'll show a success message with template details
        const templateName = language === 'zh-TW' || language === 'zh-CN' ? template.nameZh : template.name;
        alert(`${language === 'zh-TW' ? '模板已選擇' : language === 'zh-CN' ? '模板已选择' : 'Template selected'}: "${templateName}"\n\n${language === 'zh-TW' ? '您現在可以使用此模板創建您的名片。' : language === 'zh-CN' ? '您现在可以使用此模板创建您的名片。' : 'You can now create your card using this template.'}`);
        
        // In a real application, you would navigate to a card creation page:
        // router.push(`/create-card?template=${selectedTemplate}`);
      }
    }
  };

  const renderTemplatePreview = (template: Template) => {
    const isSelected = selectedTemplate === template.id;
    
    return (
      <Card 
        key={template.id}
        className={`relative cursor-pointer transition-all duration-200 hover:shadow-lg ${
          isSelected ? 'ring-2 ring-blue-500 shadow-lg' : ''
        }`}
        onClick={() => handleSelectTemplate(template.id)}
      >
        <CardContent className="p-0">
          {/* Template Preview */}
          <div 
            className="h-48 relative overflow-hidden"
            style={{ background: template.style.background }}
          >
            <div className="absolute inset-0 p-4 flex flex-col justify-between">
              {/* Top section */}
              <div>
                <h3 className={`font-bold text-lg ${template.style.textColor}`}>
                  {template.preview.name}
                </h3>
                <p className={`text-sm ${template.style.textColor} opacity-90`}>
                  {template.preview.title}
                </p>
              </div>
              
              {/* Bottom section */}
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <Building className={`w-3 h-3 ${template.style.textColor} opacity-75`} />
                  <span className={`text-xs ${template.style.textColor} opacity-90`}>
                    {template.preview.company}
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <MapPin className={`w-3 h-3 ${template.style.textColor} opacity-75`} />
                  <span className={`text-xs ${template.style.textColor} opacity-90`}>
                    {template.preview.location}
                  </span>
                </div>
              </div>
            </div>
            
            {/* Selected indicator */}
            {isSelected && (
              <div className="absolute top-2 right-2 bg-blue-500 rounded-full p-1">
                <Check className="w-4 h-4 text-white" />
              </div>
            )}
          </div>
          
          {/* Template Info */}
          <div className="p-4">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-semibold text-gray-900">
                {language === 'zh-TW' || language === 'zh-CN' ? template.nameZh : template.name}
              </h4>
              <Badge variant="secondary" className="text-xs">
                {language === 'zh-TW' || language === 'zh-CN' ? template.categoryZh : template.category}
              </Badge>
            </div>
            <p className="text-sm text-gray-600">
              {language === 'zh-TW' || language === 'zh-CN' ? template.descriptionZh : template.description}
            </p>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="text-center mb-12">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">
          {language === 'zh-TW' ? '選擇名片模板' : language === 'zh-CN' ? '选择名片模板' : 'Choose Namecard Template'}
        </h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          {language === 'zh-TW' 
            ? '從我們精選的設計模板中選擇，快速創建專業名片' 
            : language === 'zh-CN' 
            ? '从我们精选的设计模板中选择，快速创建专业名片' 
            : 'Choose from our curated design templates to quickly create professional namecards'
          }
        </p>
      </div>

      {/* Templates Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {templates.map(renderTemplatePreview)}
      </div>

      {/* Action Button */}
      <div className="text-center">
        <Button 
          onClick={handleUseTemplate}
          disabled={!selectedTemplate}
          className="px-8 py-3 text-lg"
        >
          {selectedTemplate 
            ? (language === 'zh-TW' ? '使用此模板' : language === 'zh-CN' ? '使用此模板' : 'Use This Template')
            : (language === 'zh-TW' ? '請選擇模板' : language === 'zh-CN' ? '请选择模板' : 'Select a Template')
          }
        </Button>
      </div>

      {/* Template Details */}
      {selectedTemplate && (
        <div className="mt-12 bg-gray-50 rounded-lg p-6">
          <h2 className="text-xl font-semibold mb-4">
            {language === 'zh-TW' ? '模板詳情' : language === 'zh-CN' ? '模板详情' : 'Template Details'}
          </h2>
          {(() => {
            const template = templates.find(t => t.id === selectedTemplate);
            if (!template) return null;
            
            return (
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-medium mb-2">
                    {language === 'zh-TW' ? '設計特點' : language === 'zh-CN' ? '设计特点' : 'Design Features'}
                  </h3>
                  <ul className="space-y-1 text-sm text-gray-600">
                    <li>• {language === 'zh-TW' ? '專業設計' : language === 'zh-CN' ? '专业设计' : 'Professional design'}</li>
                    <li>• {language === 'zh-TW' ? '響應式佈局' : language === 'zh-CN' ? '响应式布局' : 'Responsive layout'}</li>
                    <li>• {language === 'zh-TW' ? '高質質圖形' : language === 'zh-CN' ? '高质量图形' : 'High quality graphics'}</li>
                    <li>• {language === 'zh-TW' ? '易於自定義' : language === 'zh-CN' ? '易于自定义' : 'Easy to customize'}</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-medium mb-2">
                    {language === 'zh-TW' ? '包含內容' : language === 'zh-CN' ? '包含内容' : 'Included Elements'}
                  </h3>
                  <ul className="space-y-1 text-sm text-gray-600">
                    <li>• {language === 'zh-TW' ? '姓名和職位' : language === 'zh-CN' ? '姓名和职位' : 'Name and title'}</li>
                    <li>• {language === 'zh-TW' ? '公司信息' : language === 'zh-CN' ? '公司信息' : 'Company information'}</li>
                    <li>• {language === 'zh-TW' ? '聯絡方式' : language === 'zh-CN' ? '联络方式' : 'Contact details'}</li>
                    <li>• {language === 'zh-TW' ? '社交媒體鏈接' : language === 'zh-CN' ? '社交媒体链接' : 'Social media links'}</li>
                  </ul>
                </div>
              </div>
            );
          })()}
        </div>
      )}
    </div>
  );
}
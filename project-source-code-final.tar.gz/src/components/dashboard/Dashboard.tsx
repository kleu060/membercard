'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { 
  User, 
  Plus, 
  Eye, 
  Share2, 
  Download, 
  Mail, 
  TrendingUp,
  Calendar,
  Briefcase,
  Users,
  LogOut,
  Settings,
  QrCode
} from 'lucide-react';

import BusinessCardForm from '@/components/cards/BusinessCardForm';
import BusinessCardDisplay from '@/components/cards/BusinessCardDisplay';
import Marketplace from '@/components/marketplace/Marketplace';
import EmailSignatureGenerator from '@/components/signature/EmailSignatureGenerator';

interface DashboardProps {
  user: any;
}

export default function Dashboard({ user }: DashboardProps) {
  const [cards, setCards] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedCard, setSelectedCard] = useState<any>(null);
  const [editingCard, setEditingCard] = useState<any>(null);
  const [creatingCard, setCreatingCard] = useState(false);

  useEffect(() => {
    fetchCards();
  }, []);

  const fetchCards = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/cards');
      const data = await response.json();
      
      if (response.ok) {
        setCards(data.cards);
      }
    } catch (error) {
      console.error('Failed to fetch cards:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCardSave = (card: any) => {
    setEditingCard(null);
    setCreatingCard(false);
    fetchCards();
  };

  const handleCardEdit = (card: any) => {
    setEditingCard(card);
    setActiveTab('create');
  };

  const handleCardDelete = async (cardId: string) => {
    if (confirm('确定要删除这张名片吗？')) {
      try {
        const response = await fetch(`/api/cards/${cardId}`, {
          method: 'DELETE'
        });
        
        if (response.ok) {
          fetchCards();
        }
      } catch (error) {
        console.error('Failed to delete card:', error);
      }
    }
  };

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
      window.location.reload();
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  const totalViews = cards.reduce((sum, card) => sum + (card.viewCount || 0), 0);
  const publicCards = cards.filter(card => card.isPublic).length;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <Briefcase className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-xl font-bold text-gray-900">APEXCARD</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                {user.avatar ? (
                  <img 
                    src={user.avatar} 
                    alt={user.name}
                    className="w-8 h-8 rounded-full"
                  />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center">
                    <User className="w-4 h-4 text-gray-600" />
                  </div>
                )}
                <span className="text-sm font-medium text-gray-700">{user.name}</span>
              </div>
              
              <Button variant="outline" size="sm" onClick={handleLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                退出
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="overview">概览</TabsTrigger>
            <TabsTrigger value="my-cards">我的名片</TabsTrigger>
            <TabsTrigger value="create">创建名片</TabsTrigger>
            <TabsTrigger value="marketplace">名片市场</TabsTrigger>
            <TabsTrigger value="signature">邮件签名</TabsTrigger>
            <TabsTrigger value="settings">设置</TabsTrigger>
          </TabsList>

          {/* Overview */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid md:grid-cols-4 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-2">
                    <Briefcase className="w-8 h-8 text-blue-600" />
                    <div>
                      <p className="text-2xl font-bold">{cards.length}</p>
                      <p className="text-sm text-gray-600">总名片数</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-2">
                    <Eye className="w-8 h-8 text-green-600" />
                    <div>
                      <p className="text-2xl font-bold">{totalViews}</p>
                      <p className="text-sm text-gray-600">总浏览量</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-2">
                    <Users className="w-8 h-8 text-purple-600" />
                    <div>
                      <p className="text-2xl font-bold">{publicCards}</p>
                      <p className="text-sm text-gray-600">公开名片</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-2">
                    <Calendar className="w-8 h-8 text-orange-600" />
                    <div>
                      <p className="text-2xl font-bold">
                        {new Date().toLocaleDateString('zh-CN', { month: 'long' })}
                      </p>
                      <p className="text-sm text-gray-600">本月</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Cards */}
            <Card>
              <CardHeader>
                <CardTitle>最近的名片</CardTitle>
                <CardDescription>您最近创建或修改的名片</CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="space-y-4">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="h-20 bg-gray-200 rounded-lg animate-pulse"></div>
                    ))}
                  </div>
                ) : cards.length > 0 ? (
                  <div className="space-y-4">
                    {cards.slice(0, 5).map((card) => (
                      <div key={card.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-4">
                          {card.avatar ? (
                            <img 
                              src={card.avatar} 
                              alt={card.name}
                              className="w-12 h-12 rounded-full"
                            />
                          ) : (
                            <div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center">
                              <User className="w-6 h-6 text-gray-500" />
                            </div>
                          )}
                          <div>
                            <h3 className="font-semibold">{card.name}</h3>
                            <p className="text-sm text-gray-600">{card.company || '无公司'}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant={card.isPublic ? "default" : "secondary"}>
                            {card.isPublic ? "公开" : "私有"}
                          </Badge>
                          <div className="flex items-center space-x-1 text-sm text-gray-500">
                            <Eye className="w-4 h-4" />
                            <span>{card.viewCount || 0}</span>
                          </div>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleCardEdit(card)}
                          >
                            编辑
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Briefcase className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">还没有名片</h3>
                    <p className="text-gray-600 mb-4">创建您的第一张数字名片</p>
                    <Button onClick={() => setActiveTab('create')}>
                      <Plus className="w-4 h-4 mr-2" />
                      创建名片
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* My Cards */}
          <TabsContent value="my-cards" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">我的名片</h2>
              <Button onClick={() => setCreatingCard(true)}>
                <Plus className="w-4 h-4 mr-2" />
                新建名片
              </Button>
            </div>

            {loading ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardContent className="p-6">
                      <div className="h-32 bg-gray-200 rounded-lg mb-4"></div>
                      <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                      <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : cards.length > 0 ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {cards.map((card) => (
                  <Card key={card.id} className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center space-x-3">
                          {card.avatar ? (
                            <img 
                              src={card.avatar} 
                              alt={card.name}
                              className="w-12 h-12 rounded-full"
                            />
                          ) : (
                            <div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center">
                              <User className="w-6 h-6 text-gray-500" />
                            </div>
                          )}
                          <div>
                            <h3 className="font-semibold">{card.name}</h3>
                            <p className="text-sm text-gray-600">{card.company || '无公司'}</p>
                          </div>
                        </div>
                        <Badge variant={card.isPublic ? "default" : "secondary"}>
                          {card.isPublic ? "公开" : "私有"}
                        </Badge>
                      </div>
                      
                      <div className="space-y-2 mb-4">
                        {card.position && (
                          <p className="text-sm text-gray-600">{card.position}</p>
                        )}
                        <div className="flex items-center space-x-1 text-sm text-gray-500">
                          <Eye className="w-4 h-4" />
                          <span>{card.viewCount || 0} 次浏览</span>
                        </div>
                      </div>
                      
                      <div className="flex space-x-2">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="flex-1"
                          onClick={() => setSelectedCard(card)}
                        >
                          <Eye className="w-4 h-4 mr-1" />
                          查看
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleCardEdit(card)}
                        >
                          编辑
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Briefcase className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">还没有名片</h3>
                <p className="text-gray-600 mb-4">创建您的第一张数字名片</p>
                <Button onClick={() => setCreatingCard(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  创建名片
                </Button>
              </div>
            )}
          </TabsContent>

          {/* Create Card */}
          <TabsContent value="create">
            {creatingCard || editingCard ? (
              <BusinessCardForm 
                card={editingCard}
                onSave={handleCardSave}
                onCancel={() => {
                  setCreatingCard(false);
                  setEditingCard(null);
                }}
              />
            ) : (
              <div className="text-center py-12">
                <Plus className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">创建新名片</h3>
                <p className="text-gray-600 mb-4">开始创建您的专业数字名片</p>
                <Button onClick={() => setCreatingCard(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  创建名片
                </Button>
              </div>
            )}
          </TabsContent>

          {/* Marketplace */}
          <TabsContent value="marketplace">
            <Marketplace onCardClick={(card) => setSelectedCard(card)} />
          </TabsContent>

          {/* Email Signature */}
          <TabsContent value="signature">
            <EmailSignatureGenerator cards={cards} />
          </TabsContent>

          {/* Settings */}
          <TabsContent value="settings">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>账户设置</CardTitle>
                  <CardDescription>管理您的账户信息</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-4">
                      {user.avatar ? (
                        <img 
                          src={user.avatar} 
                          alt={user.name}
                          className="w-16 h-16 rounded-full"
                        />
                      ) : (
                        <div className="w-16 h-16 rounded-full bg-gray-300 flex items-center justify-center">
                          <User className="w-8 h-8 text-gray-600" />
                        </div>
                      )}
                      <div>
                        <h3 className="font-semibold">{user.name}</h3>
                        <p className="text-sm text-gray-600">{user.email}</p>
                      </div>
                    </div>
                    
                    <div className="pt-4 border-t">
                      <h4 className="font-medium mb-2">快速操作</h4>
                      <div className="flex space-x-2">
                        <Button variant="outline" onClick={handleLogout}>
                          <LogOut className="w-4 h-4 mr-2" />
                          退出登录
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>关于 APEXCARD</CardTitle>
                  <CardDescription>了解我们的服务</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <p className="text-sm text-gray-600">
                      APEXCARD 是专业的数字名片解决方案，帮助您创建、管理和分享您的商务名片。
                    </p>
                    <div className="flex items-center space-x-4 text-sm text-gray-500">
                      <span>版本 1.0.0</span>
                      <span>•</span>
                      <span>© 2024 APEXCARD</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Card View Modal */}
      {selectedCard && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold">名片详情</h2>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setSelectedCard(null)}
                >
                  关闭
                </Button>
              </div>
              <BusinessCardDisplay 
                card={selectedCard}
                isOwner={selectedCard.userId === user.id}
                onEdit={() => {
                  setSelectedCard(null);
                  handleCardEdit(selectedCard);
                }}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
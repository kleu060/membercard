'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { 
  Cloud, 
  Users, 
  Mail, 
  Building2, 
  RefreshCw, 
  CheckCircle, 
  XCircle, 
  AlertCircle,
  Download,
  Upload,
  Settings
} from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

interface ConnectedPlatform {
  provider: string;
  connected: boolean;
  lastSync?: string;
  autoSync: boolean;
}

export default function CRMSync() {
  const [platforms, setPlatforms] = useState<ConnectedPlatform[]>([
    { provider: 'google', connected: false, autoSync: false },
    { provider: 'outlook', connected: false, autoSync: false },
    { provider: 'salesforce', connected: false, autoSync: false }
  ]);
  const [syncing, setSyncing] = useState<string | null>(null);
  const [syncResults, setSyncResults] = useState<{[key: string]: { success: boolean; message: string; count?: number } }>({});
  const { language, t } = useLanguage();

  useEffect(() => {
    fetchSyncStatus();
  }, []);

  const fetchSyncStatus = async () => {
    try {
      const response = await fetch('/api/sync');
      if (response.ok) {
        const data = await response.json();
        const connectedPlatforms = data.connectedPlatforms || [];
        
        setPlatforms(prev => prev.map(platform => ({
          ...platform,
          connected: connectedPlatforms.includes(platform.provider)
        })));
      }
    } catch (error) {
      console.error('Error fetching sync status:', error);
    }
  };

  const handleConnect = async (platform: string) => {
    try {
      // Mock OAuth flow - in real app, this would redirect to OAuth provider
      const mockData = {
        providerAccountId: `${platform}_user_${Date.now()}`,
        accessToken: 'mock_access_token',
        refreshToken: 'mock_refresh_token',
        expiresAt: Date.now() + 3600000, // 1 hour
        scope: 'contacts.read contacts.write'
      };

      const response = await fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          platform,
          action: 'connect',
          data: mockData
        })
      });

      if (response.ok) {
        setPlatforms(prev => prev.map(p => 
          p.provider === platform ? { ...p, connected: true } : p
        ));
        setSyncResults(prev => ({
          ...prev,
          [platform]: { success: true, message: 'Connected successfully' }
        }));
      }
    } catch (error) {
      console.error('Error connecting platform:', error);
      setSyncResults(prev => ({
        ...prev,
        [platform]: { success: false, message: 'Connection failed' }
      }));
    }
  };

  const handleDisconnect = async (platform: string) => {
    try {
      const response = await fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          platform,
          action: 'disconnect'
        })
      });

      if (response.ok) {
        setPlatforms(prev => prev.map(p => 
          p.provider === platform ? { ...p, connected: false, autoSync: false } : p
        ));
        setSyncResults(prev => ({
          ...prev,
          [platform]: { success: true, message: 'Disconnected successfully' }
        }));
      }
    } catch (error) {
      console.error('Error disconnecting platform:', error);
    }
  };

  const handleSync = async (platform: string) => {
    setSyncing(platform);
    try {
      const response = await fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          platform,
          action: 'sync'
        })
      });

      if (response.ok) {
        const data = await response.json();
        setSyncResults(prev => ({
          ...prev,
          [platform]: { 
            success: true, 
            message: data.message, 
            count: data.syncedCount 
          }
        }));
      }
    } catch (error) {
      console.error('Error syncing platform:', error);
      setSyncResults(prev => ({
        ...prev,
        [platform]: { success: false, message: 'Sync failed' }
      }));
    } finally {
      setSyncing(null);
    }
  };

  const handleAutoSyncToggle = (platform: string, checked: boolean) => {
    setPlatforms(prev => prev.map(p => 
      p.provider === platform ? { ...p, autoSync: checked } : p
    ));
  };

  const getPlatformInfo = (platform: string) => {
    const info = {
      google: {
        name: language === 'zh-TW' ? 'Google 聯絡人' : 
               language === 'zh-CN' ? 'Google 联系人' : 'Google Contacts',
        description: language === 'zh-TW' ? '同步到 Google 聯絡人，支援 Android 手機' : 
                     language === 'zh-CN' ? '同步到 Google 联系人，支持 Android 手机' : 
                     'Sync to Google Contacts, supports Android phones',
        icon: <Users className="w-6 h-6" />,
        color: 'bg-blue-500'
      },
      outlook: {
        name: language === 'zh-TW' ? 'Outlook' : 
               language === 'zh-CN' ? 'Outlook' : 'Outlook',
        description: language === 'zh-TW' ? '同步到 Outlook 和 Microsoft 365' : 
                     language === 'zh-CN' ? '同步到 Outlook 和 Microsoft 365' : 
                     'Sync to Outlook and Microsoft 365',
        icon: <Mail className="w-6 h-6" />,
        color: 'bg-blue-600'
      },
      salesforce: {
        name: language === 'zh-TW' ? 'Salesforce' : 
               language === 'zh-CN' ? 'Salesforce' : 'Salesforce',
        description: language === 'zh-TW' ? '同步到 Salesforce CRM 系統' : 
                     language === 'zh-CN' ? '同步到 Salesforce CRM 系统' : 
                     'Sync to Salesforce CRM system',
        icon: <Building2 className="w-6 h-6" />,
        color: 'bg-green-600'
      }
    };

    return info[platform as keyof typeof info] || info.google;
  };

  const getLocalizedText = (key: string) => {
    const texts = {
      'zh-TW': {
        title: 'CRM 同步設定',
        subtitle: '將掃描的名片同步到各種 CRM 系統',
        connect: '連接',
        disconnect: '斷開連接',
        sync: '立即同步',
        syncing: '同步中...',
        autoSync: '自動同步',
        connected: '已連接',
        disconnected: '未連接',
        lastSync: '上次同步',
        syncSuccess: '同步成功',
        syncFailed: '同步失敗',
        contactsSynced: '已同步 {count} 個聯絡人',
        noPlatforms: '尚未連接任何平台',
        syncAll: '全部同步',
        settings: '同步設定'
      },
      'zh-CN': {
        title: 'CRM 同步设置',
        subtitle: '将扫描的名片同步到各种 CRM 系统',
        connect: '连接',
        disconnect: '断开连接',
        sync: '立即同步',
        syncing: '同步中...',
        autoSync: '自动同步',
        connected: '已连接',
        disconnected: '未连接',
        lastSync: '上次同步',
        syncSuccess: '同步成功',
        syncFailed: '同步失败',
        contactsSynced: '已同步 {count} 个联系人',
        noPlatforms: '尚未连接任何平台',
        syncAll: '全部同步',
        settings: '同步设置'
      },
      'en': {
        title: 'CRM Sync Settings',
        subtitle: 'Sync scanned cards to various CRM systems',
        connect: 'Connect',
        disconnect: 'Disconnect',
        sync: 'Sync Now',
        syncing: 'Syncing...',
        autoSync: 'Auto Sync',
        connected: 'Connected',
        disconnected: 'Disconnected',
        lastSync: 'Last Sync',
        syncSuccess: 'Sync Success',
        syncFailed: 'Sync Failed',
        contactsSynced: 'Synced {count} contacts',
        noPlatforms: 'No platforms connected yet',
        syncAll: 'Sync All',
        settings: 'Sync Settings'
      }
    };

    return texts[language as keyof typeof texts]?.[key as keyof typeof texts['zh-TW']] || key;
  };

  const texts = getLocalizedText('');

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">{texts.title}</h1>
        <p className="text-gray-600">{texts.subtitle}</p>
      </div>

      {/* Sync All Button */}
      <Card className="mb-6">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Cloud className="w-6 h-6 text-blue-600" />
              <div>
                <h3 className="text-lg font-semibold">{texts.syncAll}</h3>
                <p className="text-sm text-gray-600">
                  {platforms.filter(p => p.connected).length} {language === 'zh-TW' ? '個平台已連接' : 
                   language === 'zh-CN' ? '个平台已连接' : 'platforms connected'}
                </p>
              </div>
            </div>
            <Button
              onClick={() => platforms.filter(p => p.connected).forEach(p => handleSync(p.provider))}
              disabled={platforms.filter(p => p.connected).length === 0 || !!syncing}
              className="flex items-center gap-2"
            >
              <RefreshCw className={`w-4 h-4 ${syncing ? 'animate-spin' : ''}`} />
              {syncing ? texts.syncing : texts.sync}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Platform Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {platforms.map((platform) => {
          const platformInfo = getPlatformInfo(platform.provider);
          const result = syncResults[platform.provider];

          return (
            <Card key={platform.provider} className="relative">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${platformInfo.color} text-white`}>
                      {platformInfo.icon}
                    </div>
                    <div>
                      <CardTitle className="text-lg">{platformInfo.name}</CardTitle>
                      <CardDescription className="text-sm">
                        {platform.connected ? texts.connected : texts.disconnected}
                      </CardDescription>
                    </div>
                  </div>
                  <Badge 
                    variant={platform.connected ? "default" : "secondary"}
                    className={platform.connected ? "bg-green-500" : ""}
                  >
                    {platform.connected ? texts.connected : texts.disconnected}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-gray-600">{platformInfo.description}</p>

                {/* Sync Status */}
                {result && (
                  <div className={`p-3 rounded-lg ${
                    result.success ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'
                  }`}>
                    <div className="flex items-center gap-2">
                      {result.success ? (
                        <CheckCircle className="w-4 h-4 text-green-600" />
                      ) : (
                        <XCircle className="w-4 h-4 text-red-600" />
                      )}
                      <span className={`text-sm ${
                        result.success ? 'text-green-800' : 'text-red-800'
                      }`}>
                        {result.message}
                      </span>
                    </div>
                    {result.count && (
                      <p className="text-xs text-green-700 mt-1">
                        {texts.contactsSynced.replace('{count}', result.count.toString())}
                      </p>
                    )}
                  </div>
                )}

                {/* Actions */}
                <div className="space-y-3">
                  {platform.connected ? (
                    <>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">{texts.autoSync}</span>
                        <Switch
                          checked={platform.autoSync}
                          onCheckedChange={(checked) => handleAutoSyncToggle(platform.provider, checked)}
                        />
                      </div>
                      <div className="flex gap-2">
                        <Button
                          onClick={() => handleSync(platform.provider)}
                          disabled={syncing === platform.provider}
                          size="sm"
                          className="flex-1"
                        >
                          {syncing === platform.provider ? (
                            <RefreshCw className="w-4 h-4 animate-spin" />
                          ) : (
                            <RefreshCw className="w-4 h-4" />
                          )}
                          {syncing === platform.provider ? texts.syncing : texts.sync}
                        </Button>
                        <Button
                          onClick={() => handleDisconnect(platform.provider)}
                          size="sm"
                          variant="outline"
                          className="flex items-center gap-1"
                        >
                          <XCircle className="w-4 h-4" />
                          {texts.disconnect}
                        </Button>
                      </div>
                    </>
                  ) : (
                    <Button
                      onClick={() => handleConnect(platform.provider)}
                      size="sm"
                      className="w-full"
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      {texts.connect}
                    </Button>
                  )}
                </div>

                {/* Last Sync Info */}
                {platform.connected && platform.lastSync && (
                  <div className="text-xs text-gray-500">
                    {texts.lastSync}: {new Date(platform.lastSync).toLocaleString()}
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* No Platforms Connected */}
      {platforms.filter(p => p.connected).length === 0 && (
        <Card>
          <CardContent className="p-12 text-center">
            <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500 mb-4">{texts.noPlatforms}</p>
            <p className="text-sm text-gray-400">
              {language === 'zh-TW' ? '連接平台後，您可以將掃描的名片自動同步到對應的系統' : 
               language === 'zh-CN' ? '连接平台后，您可以将扫描的名片自动同步到对应的系统' : 
               'After connecting platforms, you can automatically sync scanned cards to corresponding systems'}
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Mail, 
  Copy, 
  Download, 
  Eye, 
  FileText, 
  Code,
  CheckCircle,
  ExternalLink
} from 'lucide-react';

interface EmailSignatureGeneratorProps {
  cards: any[];
  onGenerate?: (signature: any) => void;
}

const templates = [
  {
    id: 'modern',
    name: '现代风格',
    description: '简洁现代的设计风格',
    preview: 'modern'
  },
  {
    id: 'minimal',
    name: '极简风格',
    description: '最简洁的文本格式',
    preview: 'minimal'
  },
  {
    id: 'professional',
    name: '专业风格',
    description: '商务专业的格式',
    preview: 'professional'
  },
  {
    id: 'corporate',
    name: '企业风格',
    description: '正式企业格式',
    preview: 'corporate'
  }
];

export default function EmailSignatureGenerator({ cards, onGenerate }: EmailSignatureGeneratorProps) {
  const [selectedCard, setSelectedCard] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState('modern');
  const [htmlSignature, setHtmlSignature] = useState('');
  const [plainTextSignature, setPlainTextSignature] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState('');

  const handleGenerate = async () => {
    if (!selectedCard) {
      setError('请选择一个名片');
      return;
    }

    setIsGenerating(true);
    setError('');

    try {
      const response = await fetch('/api/signature', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          cardId: selectedCard,
          template: selectedTemplate
        })
      });

      const data = await response.json();

      if (response.ok) {
        setHtmlSignature(data.htmlSignature);
        setPlainTextSignature(data.plainTextSignature);
        onGenerate?.(data);
      } else {
        setError(data.error || '生成失败');
      }
    } catch (error) {
      setError('网络错误');
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error('复制失败');
    }
  };

  const downloadHTML = () => {
    const blob = new Blob([htmlSignature], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'email-signature.html';
    a.click();
    URL.revokeObjectURL(url);
  };

  const downloadText = () => {
    const blob = new Blob([plainTextSignature], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'email-signature.txt';
    a.click();
    URL.revokeObjectURL(url);
  };

  const emailClients = [
    {
      name: 'Gmail',
      instructions: [
        '打开 Gmail 设置',
        '点击 "查看所有设置"',
        '在 "常规" 标签页中找到 "签名"',
        '将 HTML 签名粘贴到签名框中',
        '保存更改'
      ]
    },
    {
      name: 'Outlook',
      instructions: [
        '打开 Outlook',
        '点击 "文件" > "选项" > "邮件"',
        '点击 "签名" 按钮',
        '新建签名并粘贴 HTML 代码',
        '保存并应用'
      ]
    },
    {
      name: 'Apple Mail',
      instructions: [
        '打开 Apple Mail',
        '点击 "Mail" > "偏好设置" > "签名"',
        '点击 + 号创建新签名',
        '取消勾选 "始终与我的字体匹配"',
        '粘贴 HTML 签名'
      ]
    },
    {
      name: 'Yahoo Mail',
      instructions: [
        '登录 Yahoo Mail',
        '点击设置图标 > "更多设置"',
        '选择 "写作邮件" > "签名"',
        '粘贴 HTML 签名代码',
        '保存设置'
      ]
    },
    {
      name: 'Thunderbird',
      instructions: [
        '打开 Thunderbird',
        '点击菜单 > "账户设置"',
        '选择要配置的账户',
        '在 "签名" 区域粘贴 HTML 代码',
        '确定保存'
      ]
    }
  ];

  return (
    <div className="max-w-4xl mx-auto p-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail className="w-5 h-5" />
            邮件签名生成器
          </CardTitle>
          <CardDescription>
            为您的邮箱创建专业的邮件签名
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {/* Selection */}
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">选择名片</label>
                <Select value={selectedCard} onValueChange={setSelectedCard}>
                  <SelectTrigger>
                    <SelectValue placeholder="选择要使用的名片" />
                  </SelectTrigger>
                  <SelectContent>
                    {cards.map((card) => (
                      <SelectItem key={card.id} value={card.id}>
                        {card.name} - {card.company || '无公司'}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">选择模板</label>
                <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {templates.map((template) => (
                      <SelectItem key={template.id} value={template.id}>
                        {template.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <Button onClick={handleGenerate} disabled={isGenerating || !selectedCard}>
              {isGenerating ? '生成中...' : '生成签名'}
            </Button>

            {/* Preview */}
            {(htmlSignature || plainTextSignature) && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold">预览</h3>
                
                <Tabs defaultValue="html" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="html">HTML 签名</TabsTrigger>
                    <TabsTrigger value="text">纯文本签名</TabsTrigger>
                  </TabsList>

                  <TabsContent value="html" className="space-y-4">
                    <div className="border rounded-lg p-4 bg-white">
                      <div 
                        dangerouslySetInnerHTML={{ __html: htmlSignature }}
                        className="signature-preview"
                      />
                    </div>
                    
                    <div className="flex space-x-2">
                      <Button 
                        variant="outline" 
                        onClick={() => copyToClipboard(htmlSignature)}
                        className="flex items-center gap-2"
                      >
                        {copied ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                        {copied ? '已复制' : '复制 HTML'}
                      </Button>
                      <Button 
                        variant="outline" 
                        onClick={downloadHTML}
                        className="flex items-center gap-2"
                      >
                        <Download className="w-4 h-4" />
                        下载 HTML
                      </Button>
                    </div>

                    <div className="mt-4">
                      <h4 className="font-medium mb-2 flex items-center gap-2">
                        <Code className="w-4 h-4" />
                        HTML 代码
                      </h4>
                      <div className="bg-gray-100 p-4 rounded-lg overflow-x-auto">
                        <pre className="text-sm text-gray-800 whitespace-pre-wrap">
                          {htmlSignature}
                        </pre>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="text" className="space-y-4">
                    <div className="border rounded-lg p-4 bg-gray-50">
                      <pre className="text-sm text-gray-800 whitespace-pre-wrap font-sans">
                        {plainTextSignature}
                      </pre>
                    </div>
                    
                    <div className="flex space-x-2">
                      <Button 
                        variant="outline" 
                        onClick={() => copyToClipboard(plainTextSignature)}
                        className="flex items-center gap-2"
                      >
                        {copied ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                        {copied ? '已复制' : '复制文本'}
                      </Button>
                      <Button 
                        variant="outline" 
                        onClick={downloadText}
                        className="flex items-center gap-2"
                      >
                        <Download className="w-4 h-4" />
                        下载文本
                      </Button>
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
            )}

            {/* Email Client Instructions */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">邮件客户端设置指南</h3>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
                {emailClients.map((client, index) => (
                  <Card key={index}>
                    <CardHeader>
                      <CardTitle className="text-lg">{client.name}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ol className="space-y-2 text-sm">
                        {client.instructions.map((instruction, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <Badge variant="outline" className="mt-0.5 text-xs">
                              {i + 1}
                            </Badge>
                            <span>{instruction}</span>
                          </li>
                        ))}
                      </ol>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
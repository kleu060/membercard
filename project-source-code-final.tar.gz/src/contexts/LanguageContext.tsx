'use client';

import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type Language = 'zh-TW' | 'zh-CN' | 'en';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translations = {
  'zh-TW': {
    // Header
    'nav.features': '功能特色',
    'nav.advantages': '核心優勢',
    'nav.marketplace': '名片市場',
    'nav.getStarted': '開始使用',
    
    // Hero Section
    'hero.mainTitle': '專業數位名片解決方案',
    'hero.feature1.title': '定制您的專屬電子名片',
    'hero.feature1.subtitle': '您的數位商務身份',
    'hero.feature1.description': '免費建立，即時分享',
    'hero.feature2.title': '整合社交與商務資料',
    'hero.feature2.subtitle': '統一社交與專業檔案',
    'hero.feature2.description': '一站式管理您的所有社交和商務聯繫資訊',
    'hero.feature3.title': '精選設計模板庫',
    'hero.feature3.subtitle': '精心策劃的設計模板',
    'hero.feature3.description': '專業設計師打造，滿足不同行業需求',
    'hero.cta1': '立即開啟高效商務社交',
    'hero.cta2': '免費獲得 APEXCARD',
    
    // Features Section
    'features.title': '電子名片優勢',
    'features.subtitle': '打造您的專業數位形象',
    'features.item1.title': '多功能整合：個人微型門戶網站',
    'features.item1.subtitle': '多合一數位中心',
    'features.item1.description': '將您的所有資訊整合在一個專業的數位名片中',
    'features.item2.title': '跨平台分享：全球秒速傳遞名片',
    'features.item2.subtitle': '隨時隨地分享',
    'features.item2.description': '透過連結、二維碼、NFC等多種方式快速分享',
    'features.item3.title': '連結聚合：集中展示關鍵觸點',
    'features.item3.subtitle': '集中管理您的關鍵連結',
    'features.item3.description': 'LINE、電商、社群等所有重要連結一站式展示',
    
    // CTA Section
    'cta.title': '🎯 行動召喚',
    'cta.subtitle': '立即開啟高效商務社交',
    'cta.subtitle2': '免費獲得 APEXCARD',
    'cta.button1': '免費開始使用',
    'cta.button2': '了解更多',
    
    // Footer
    'footer.tagline': '您的專業數位名片解決方案',
    'footer.products': '產品功能',
    'footer.product1': '數位名片',
    'footer.product2': '名片市場',
    'footer.product3': '郵件簽名',
    'footer.product4': '客戶管理',
    'footer.support': '支援',
    'footer.support1': '幫助中心',
    'footer.support2': '聯繫我們',
    'footer.support3': 'API 文件',
    'footer.support4': '狀態頁面',
    'footer.follow': '關注我們',
    'footer.copyright': '© 2024 APEXCARD. 版權所有。',
    
    // Common
    'loading': '載入中...',
    'edit': '編輯',
    'share': '分享',
    'save': '儲存',
    'close': '關閉',
    'contact': '聯絡方式',
    'social': '社交媒體',
    'products': '產品/服務',
    'industry': '行業標籤',
    'bio': '個人簡介',
    'saveToContacts': '儲存到通訊錄',
    'qrCode': '二維碼',
    'saveCard': '收藏名片',
    'scanQR': '掃描二維碼',
    'scanQRDesc': '掃描二維碼快速儲存聯絡資訊',
    'createdAt': '建立於',
  },
  'zh-CN': {
    // Header
    'nav.features': '功能特色',
    'nav.advantages': '核心优势',
    'nav.marketplace': '名片市场',
    'nav.getStarted': '开始使用',
    
    // Hero Section
    'hero.mainTitle': '专业数字名片解决方案',
    'hero.feature1.title': '定制你的专属电子名片',
    'hero.feature1.subtitle': '免费创建 · 即时分享',
    'hero.feature1.description': '',
    'hero.feature2.title': '整合社交与商务资料',
    'hero.feature2.subtitle': '一站式管理您的所有社交和商务联系信息',
    'hero.feature2.description': '',
    'hero.feature3.title': '精选设计模板库',
    'hero.feature3.subtitle': '专业设计师打造，满足不同行业需求',
    'hero.feature3.description': '',
    'hero.cta1': '立即开启高效商务社交',
    'hero.cta2': '免费获得 APEXCARD',
    
    // Features Section
    'features.title': '电子名片优势',
    'features.subtitle': '打造您的专业数字形象',
    'features.item1.title': '多功能整合：个人微型门户网站',
    'features.item1.subtitle': '',
    'features.item1.description': '将您的所有信息整合在一个专业的数字名片中',
    'features.item2.title': '跨平台分享：全球秒速传递名片',
    'features.item2.subtitle': '',
    'features.item2.description': '通过链接、二维码、NFC等多种方式快速分享',
    'features.item3.title': '链接聚合：集中展示关键触点',
    'features.item3.subtitle': '',
    'features.item3.description': 'LINE、电商、社群等所有重要链接一站式展示',
    
    // CTA Section
    'cta.title': '🎯 行动召唤',
    'cta.subtitle': '立即开启高效商务社交',
    'cta.subtitle2': '免费获得 APEXCARD',
    'cta.button1': '免费开始使用',
    'cta.button2': '了解更多',
    
    // Footer
    'footer.tagline': '您的专业数字名片解决方案',
    'footer.products': '产品功能',
    'footer.product1': '数字名片',
    'footer.product2': '名片市场',
    'footer.product3': '邮件签名',
    'footer.product4': '客户管理',
    'footer.support': '支持',
    'footer.support1': '帮助中心',
    'footer.support2': '联系我们',
    'footer.support3': 'API 文档',
    'footer.support4': '状态页面',
    'footer.follow': '关注我们',
    'footer.copyright': '© 2024 APEXCARD. 版权所有。',
    
    // Common
    'loading': '加载中...',
    'edit': '编辑',
    'share': '分享',
    'save': '保存',
    'close': '关闭',
    'contact': '联系方式',
    'social': '社交媒体',
    'products': '产品/服务',
    'industry': '行业标签',
    'bio': '个人简介',
    'saveToContacts': '保存到通讯录',
    'qrCode': '二维码',
    'saveCard': '收藏名片',
    'scanQR': '扫描二维码',
    'scanQRDesc': '扫描二维码快速保存联系信息',
    'createdAt': '创建于',
  },
  'en': {
    // Header
    'nav.features': 'Features',
    'nav.advantages': 'Advantages',
    'nav.marketplace': 'Marketplace',
    'nav.getStarted': 'Get Started',
    
    // Hero Section
    'hero.mainTitle': 'Professional Digital Card Solution',
    'hero.feature1.title': 'Customize Your Exclusive Digital Card',
    'hero.feature1.subtitle': 'Your Digital Business Identity',
    'hero.feature1.description': 'Free Sign-Up, Instant Sharing',
    'hero.feature2.title': 'Integrate Social & Business Profiles',
    'hero.feature2.subtitle': 'Unify Social & Professional Profiles',
    'hero.feature2.description': 'One-stop management for all your social and business contact information',
    'hero.feature3.title': 'Curated Design Templates',
    'hero.feature3.subtitle': 'Professionally Designed Templates',
    'hero.feature3.description': 'Created by professional designers for various industries',
    'hero.cta1': 'Start Efficient Business Networking',
    'hero.cta2': 'Get APEXCARD - Free Forever',
    
    // Features Section
    'features.title': 'Digital Card Advantages',
    'features.subtitle': 'Build Your Professional Digital Identity',
    'features.item1.title': 'Multi-functional Integration: Personal Micro Portal',
    'features.item1.subtitle': 'All-in-One Digital Hub',
    'features.item1.description': 'Integrate all your information in one professional digital card',
    'features.item2.title': 'Cross-platform Sharing: Global Instant Card Delivery',
    'features.item2.subtitle': 'Share Anytime, Anywhere',
    'features.item2.description': 'Quick sharing via links, QR codes, NFC and more',
    'features.item3.title': 'Link Aggregation: Centralized Key Touchpoints',
    'features.item3.subtitle': 'Centralize Your Key Links',
    'features.item3.description': 'One-stop display for all important links like LINE, e-commerce, communities',
    
    // CTA Section
    'cta.title': '🎯 Call to Action',
    'cta.subtitle': 'Start Efficient Business Networking Now',
    'cta.subtitle2': 'Get APEXCARD - Free Forever',
    'cta.button1': 'Get Started Free',
    'cta.button2': 'Learn More',
    
    // Footer
    'footer.tagline': 'Your Professional Digital Card Solution',
    'footer.products': 'Products',
    'footer.product1': 'Digital Cards',
    'footer.product2': 'Card Marketplace',
    'footer.product3': 'Email Signatures',
    'footer.product4': 'Client Management',
    'footer.support': 'Support',
    'footer.support1': 'Help Center',
    'footer.support2': 'Contact Us',
    'footer.support3': 'API Documentation',
    'footer.support4': 'Status Page',
    'footer.follow': 'Follow Us',
    'footer.copyright': '© 2024 APEXCARD. All rights reserved.',
    
    // Common
    'loading': 'Loading...',
    'edit': 'Edit',
    'share': 'Share',
    'save': 'Save',
    'close': 'Close',
    'contact': 'Contact Information',
    'social': 'Social Media',
    'products': 'Products/Services',
    'industry': 'Industry Tags',
    'bio': 'Personal Bio',
    'saveToContacts': 'Save to Contacts',
    'qrCode': 'QR Code',
    'saveCard': 'Save Card',
    'scanQR': 'Scan QR Code',
    'scanQRDesc': 'Scan QR code to quickly save contact information',
    'createdAt': 'Created at',
  }
};

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('zh-TW');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') as Language;
    if (savedLanguage && translations[savedLanguage]) {
      setLanguage(savedLanguage);
    }
  }, []);

  const handleSetLanguage = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('language', lang);
  };

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations['zh-TW']] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage: handleSetLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}